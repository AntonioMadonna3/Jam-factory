package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SupplierTest {

    @Test
    public void testConstructorComplete() {
        Supplier supplier = new Supplier(1, "Azienda Agricola SRL", "12345678901", "Fragole");
        
        assertEquals(1, supplier.getId());
        assertEquals("Azienda Agricola SRL", supplier.getRagioneSociale());
        assertEquals("12345678901", supplier.getPIva());
        assertEquals("Fragole", supplier.getMateriaPrima());
    }

    @Test
    public void testConstructorWithoutId() {
        Supplier supplier = new Supplier("Azienda Agricola SRL", "12345678901", "Fragole");
        
        assertEquals("Azienda Agricola SRL", supplier.getRagioneSociale());
        assertEquals("12345678901", supplier.getPIva());
        assertEquals("Fragole", supplier.getMateriaPrima());
    }

    @Test
    public void testSetters() {
        Supplier supplier = new Supplier("Azienda", "12345678901", "Fragole");
        
        supplier.setId(10);
        supplier.setRagioneSociale("Nuova Azienda SRL");
        supplier.setPIva("98765432109");
        supplier.setMateriaPrima("Mirtilli");
        
        assertEquals(10, supplier.getId());
        assertEquals("Nuova Azienda SRL", supplier.getRagioneSociale());
        assertEquals("98765432109", supplier.getPIva());
        assertEquals("Mirtilli", supplier.getMateriaPrima());
    }
}
