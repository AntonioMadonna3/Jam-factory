package model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import model.User.Role;

class UserTest {

    @Test
    void testUserCreation_ValidData() {
        User user = new User(1, "test@test.com", "Test User", Role.CLIENT);

        assertEquals(1, user.getId());
        assertEquals("test@test.com", user.getEmail());
        assertEquals("Test User", user.getFirstName());
        assertEquals(Role.CLIENT, user.getRole());
    }

    @Test
    void testSettersAndGetters() {
        User user = new User(1, "old@test.com", "Old Name", Role.CLIENT);

        user.setId(2);
        user.setEmail("new@test.com");
        user.setFirstName("New Name");
        user.setRole(Role.ADMIN);

        assertEquals(2, user.getId());
        assertEquals("new@test.com", user.getEmail());
        assertEquals("New Name", user.getFirstName());
        assertEquals(Role.ADMIN, user.getRole());
    }

    @Test
    void testRoleEnum_AllValues() {
        assertNotNull(Role.ADMIN);
        assertNotNull(Role.CLIENT);
        assertNotNull(Role.EMPLOYEE);

        assertEquals(Role.ADMIN, Role.valueOf("ADMIN"));
        assertEquals(Role.CLIENT, Role.valueOf("CLIENT"));
        assertEquals(Role.EMPLOYEE, Role.valueOf("EMPLOYEE"));
    }

    @Test
    void testRoleEnum_ToString() {
        assertEquals("ADMIN", Role.ADMIN.toString());
        assertEquals("CLIENT", Role.CLIENT.toString());
        assertEquals("EMPLOYEE", Role.EMPLOYEE.toString());
    }
}
