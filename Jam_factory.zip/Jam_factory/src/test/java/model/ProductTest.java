package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;

public class ProductTest {

    @Test
    public void testConstructorComplete() {
        Product product = new Product(1, "Marmellata", "Marmellata di fragole", new BigDecimal("5.50"), 100);
        
        assertEquals(1, product.getId());
        assertEquals("Marmellata", product.getNome());
        assertEquals("Marmellata di fragole", product.getDescrizione());
        assertEquals(new BigDecimal("5.50"), product.getPrezzo());
        assertEquals(100, product.getStock());
    }

    @Test
    public void testConstructorWithoutIdAndStock() {
        Product product = new Product("Marmellata", "Marmellata di fragole", new BigDecimal("5.50"));
        
        assertEquals("Marmellata", product.getNome());
        assertEquals("Marmellata di fragole", product.getDescrizione());
        assertEquals(new BigDecimal("5.50"), product.getPrezzo());
    }

    @Test
    public void testSetters() {
        Product product = new Product("Marmellata", "Descrizione", new BigDecimal("5.50"));
        
        product.setId(10);
        product.setStock(50);
        
        assertEquals(10, product.getId());
        assertEquals(50, product.getStock());
    }
}
