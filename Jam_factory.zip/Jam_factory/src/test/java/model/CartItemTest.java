package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;

public class CartItemTest {

    @Test
    public void testConstructor() {
        CartItem item = new CartItem(1, "Marmellata", new BigDecimal("5.50"), 3, 10);
        
        assertEquals(1, item.getProductId());
        assertEquals("Marmellata", item.getProductName());
        assertEquals(new BigDecimal("5.50"), item.getUnitPrice());
        assertEquals(3, item.getQuantity());
        assertEquals(10, item.getAvailableStock());
    }

    @Test
    public void testGetSubtotal() {
        CartItem item = new CartItem(1, "Marmellata", new BigDecimal("5.50"), 3, 10);
        BigDecimal expectedSubtotal = new BigDecimal("16.50");
        
        assertEquals(expectedSubtotal, item.getSubtotal());
    }

    @Test
    public void testSetQuantity() {
        CartItem item = new CartItem(1, "Marmellata", new BigDecimal("5.50"), 3, 10);
        item.setQuantity(5);
        
        assertEquals(5, item.getQuantity());
    }
}
