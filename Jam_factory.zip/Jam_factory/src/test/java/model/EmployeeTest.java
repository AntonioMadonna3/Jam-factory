package model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


class EmployeeTest {

    @Test
    void testEmployeeCreation_WithPassword() {
        Employee employee = new Employee("Mario", "Rossi", "mario@test.com", "password123");

        assertEquals("Mario", employee.getNome());
        assertEquals("Rossi", employee.getCognome());
        assertEquals("mario@test.com", employee.getEmail());
        assertEquals("password123", employee.getPassword());
        assertEquals(0, employee.getId()); // default value
    }

    @Test
    void testEmployeeCreation_WithoutPassword() {
        Employee employee = new Employee(1, "Luigi", "Verdi", "luigi@test.com");

        assertEquals(1, employee.getId());
        assertEquals("Luigi", employee.getNome());
        assertEquals("Verdi", employee.getCognome());
        assertEquals("luigi@test.com", employee.getEmail());
        assertNull(employee.getPassword());
    }

    @Test
    void testSetId() {
        Employee employee = new Employee("Test", "User", "test@test.com", "password");
        
        employee.setId(42);
        
        assertEquals(42, employee.getId());
    }
}
