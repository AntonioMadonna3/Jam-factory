package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class CustomerOrderTest {

    @Test
    public void testConstructor() {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        CustomerOrder order = new CustomerOrder(1, 100, new BigDecimal("25.50"), timestamp);
        
        assertEquals(1, order.getId());
        assertEquals(100, order.getCustomerId());
        assertEquals(new BigDecimal("25.50"), order.getTotalEur());
        assertEquals(timestamp, order.getOrderedAt());
    }

    @Test
    public void testCustomerNameSetterGetter() {
        CustomerOrder order = new CustomerOrder(1, 100, new BigDecimal("25.50"), new Timestamp(System.currentTimeMillis()));
        order.setCustomerName("Mario Rossi");
        
        assertEquals("Mario Rossi", order.getCustomerName());
    }

    @Test
    public void testItemsSetterGetter() {
        CustomerOrder order = new CustomerOrder(1, 100, new BigDecimal("25.50"), new Timestamp(System.currentTimeMillis()));
        List<CartItem> items = new ArrayList<>();
        items.add(new CartItem(1, "Marmellata", new BigDecimal("5.50"), 2, 10));
        
        order.setItems(items);
        
        assertEquals(items, order.getItems());
        assertEquals(1, order.getItems().size());
    }
}
