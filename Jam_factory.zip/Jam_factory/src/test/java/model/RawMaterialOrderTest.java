package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class RawMaterialOrderTest {

    @Test
    public void testConstructorComplete() {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        RawMaterialOrder order = new RawMaterialOrder(1, 5, new BigDecimal("100.50"), timestamp);
        
        assertEquals(1, order.getId());
        assertEquals(5, order.getSupplierId());
        assertEquals(new BigDecimal("100.50"), order.getQtyKg());
        assertEquals(timestamp, order.getOrderedAt());
    }

    @Test
    public void testConstructorSimple() {
        RawMaterialOrder order = new RawMaterialOrder(5, new BigDecimal("100.50"));
        
        assertEquals(5, order.getSupplierId());
        assertEquals(new BigDecimal("100.50"), order.getQtyKg());
    }

    @Test
    public void testSetters() {
        RawMaterialOrder order = new RawMaterialOrder(5, new BigDecimal("100.50"));
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        
        order.setId(10);
        order.setSupplierId(6);
        order.setQtyKg(new BigDecimal("200.75"));
        order.setOrderedAt(timestamp);
        order.setSupplierName("Fornitore ABC");
        order.setMateriaPrima("Fragole");
        
        assertEquals(10, order.getId());
        assertEquals(6, order.getSupplierId());
        assertEquals(new BigDecimal("200.75"), order.getQtyKg());
        assertEquals(timestamp, order.getOrderedAt());
        assertEquals("Fornitore ABC", order.getSupplierName());
        assertEquals("Fragole", order.getMateriaPrima());
    }
}
