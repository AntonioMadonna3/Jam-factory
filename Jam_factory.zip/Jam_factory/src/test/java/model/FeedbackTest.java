package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.sql.Timestamp;

public class FeedbackTest {

    @Test
    public void testConstructorBasic() {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        Feedback feedback = new Feedback(1, 2, 5, "Ottimo prodotto", timestamp);
        
        assertEquals(1, feedback.getEmployeeId());
        assertEquals(2, feedback.getProductId());
        assertEquals(5, feedback.getRating());
        assertEquals("Ottimo prodotto", feedback.getNote());
        assertEquals(timestamp, feedback.getGivenAt());
    }

    @Test
    public void testConstructorComplete() {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        Feedback feedback = new Feedback(1, 2, "Marmellata", "Mario Rossi", 4, "Buono", timestamp);
        
        assertEquals(1, feedback.getEmployeeId());
        assertEquals(2, feedback.getProductId());
        assertEquals("Marmellata", feedback.getProductName());
        assertEquals("Mario Rossi", feedback.getEmployeeName());
        assertEquals(4, feedback.getRating());
        assertEquals("Buono", feedback.getNote());
        assertEquals(timestamp, feedback.getGivenAt());
    }

    @Test
    public void testSetters() {
        Feedback feedback = new Feedback(1, 2, 5, "Ottimo", new Timestamp(System.currentTimeMillis()));
        
        feedback.setProductName("Marmellata di fragole");
        feedback.setEmployeeName("Luca Bianchi");
        
        assertEquals("Marmellata di fragole", feedback.getProductName());
        assertEquals("Luca Bianchi", feedback.getEmployeeName());
    }
}
