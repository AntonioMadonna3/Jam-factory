package dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import model.Customer;

class CustomerTest {

    @Test
    void testCustomerCreation_WithPassword() {
        Customer customer = new Customer("Test Company SRL", "12345678901", "test@company.com", "password123");

        assertEquals("Test Company SRL", customer.getRagioneSociale());
        assertEquals("12345678901", customer.getPIva());
        assertEquals("test@company.com", customer.getEmail());
        assertEquals("password123", customer.getPassword());
        assertEquals(0, customer.getId()); // default value
    }

    @Test
    void testCustomerCreation_WithoutPassword() {
        Customer customer = new Customer(1, "Another Company", "98765432109", "another@company.com");

        assertEquals(1, customer.getId());
        assertEquals("Another Company", customer.getRagioneSociale());
        assertEquals("98765432109", customer.getPIva());
        assertEquals("another@company.com", customer.getEmail());
        assertNull(customer.getPassword());
    }

    @Test
    void testSetId() {
        Customer customer = new Customer("Test", "123", "test@test.com", "password");
        
        customer.setId(99);
        
        assertEquals(99, customer.getId());
    }
}
