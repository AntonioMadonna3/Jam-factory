package dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Feedback;
import model.Product;
import java.util.List;

class FeedbackDaoTest {
    
    private FeedbackDao feedbackDao;
    
    @BeforeEach
    void setUp() {
        feedbackDao = new FeedbackDao();
    }
    
    @Test
    void testGetAllFeedback() {
        List<Feedback> feedbacks = feedbackDao.getAllFeedback();
        assertNotNull(feedbacks);
    }
    
    @Test
    void testGetEmployeeFeedbackInvalidEmployee() {
        List<Feedback> feedbacks = feedbackDao.getEmployeeFeedback(-1);
        assertNotNull(feedbacks);
        assertTrue(feedbacks.isEmpty());
    }
    
    @Test
    void testHasEmployeeGivenFeedbackInvalidIds() {
        boolean hasFeedback = feedbackDao.hasEmployeeGivenFeedback(-1, -1);
        assertFalse(hasFeedback);
    }
    
    @Test
    void testGetProductsAvailableForFeedbackInvalidEmployee() {
        List<Product> products = feedbackDao.getProductsAvailableForFeedback(-1);
        assertNotNull(products);
    }
    
    @Test
    void testAddFeedbackInvalidData() {
        boolean result = feedbackDao.addFeedback(-1, -1, 0, "Test note");
        assertFalse(result); // Should fail with invalid employee/product IDs
    }
    
    @Test
    void testAddFeedbackInvalidRating() {
        boolean result = feedbackDao.addFeedback(1, 1, 10, "Test note"); // Rating > 5
        assertFalse(result); // Should fail with invalid rating
    }
}
