package dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

class StatsDaoTest {
    
    private StatsDao statsDao;
    
    @BeforeEach
    void setUp() {
        statsDao = new StatsDao();
    }
    
    @Test
    void testGetOverviewStats() {
        Map<String, Integer> stats = statsDao.getOverviewStats();
        assertNotNull(stats);
        
        // Check that expected keys exist and values are non-negative
        assertTrue(stats.containsKey("totalProducts"));
        assertTrue(stats.containsKey("totalCustomers"));
        assertTrue(stats.containsKey("totalEmployees"));
        assertTrue(stats.containsKey("totalSuppliers"));
        
        assertTrue(stats.get("totalProducts") >= 0);
        assertTrue(stats.get("totalCustomers") >= 0);
        assertTrue(stats.get("totalEmployees") >= 0);
        assertTrue(stats.get("totalSuppliers") >= 0);
    }
    
    @Test
    void testGetTopSellingProducts() {
        List<Map<String, Object>> products = statsDao.getTopSellingProducts(5);
        assertNotNull(products);
        assertTrue(products.size() <= 5);
    }
    
    @Test
    void testGetLeastSellingProducts() {
        List<Map<String, Object>> products = statsDao.getLeastSellingProducts(5);
        assertNotNull(products);
        assertTrue(products.size() <= 5);
    }
    
    @Test
    void testGetTopSuppliers() {
        List<Map<String, Object>> suppliers = statsDao.getTopSuppliers();
        assertNotNull(suppliers);
    }
    
    @Test
    void testGetMonthlySales() {
        List<Map<String, Object>> sales = statsDao.getMonthlySales();
        assertNotNull(sales);
        assertTrue(sales.size() <= 12); // Max 12 months
    }
    
    @Test
    void testGetTopCustomers() {
        List<Map<String, Object>> customers = statsDao.getTopCustomers(5);
        assertNotNull(customers);
        assertTrue(customers.size() <= 5);
    }
    
    @Test
    void testGetAverageOrderValue() {
        BigDecimal avgValue = statsDao.getAverageOrderValue();
        assertNotNull(avgValue);
        assertTrue(avgValue.compareTo(BigDecimal.ZERO) >= 0);
    }
    
    @Test
    void testGetTopRatedProducts() {
        List<Map<String, Object>> products = statsDao.getTopRatedProducts(5);
        assertNotNull(products);
        assertTrue(products.size() <= 5);
    }
    
    @Test
    void testGetRatingDistribution() {
        Map<Integer, Integer> distribution = statsDao.getRatingDistribution();
        assertNotNull(distribution);
        
        // Should have entries for ratings 1-5
        for (int i = 1; i <= 5; i++) {
            assertTrue(distribution.containsKey(i));
            assertTrue(distribution.get(i) >= 0);
        }
    }
}
