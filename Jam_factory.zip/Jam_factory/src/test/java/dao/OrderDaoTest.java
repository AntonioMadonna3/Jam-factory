package dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.CustomerOrder;
import model.CartItem;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

class OrderDaoTest {
    
    private OrderDao orderDao;
    
    @BeforeEach
    void setUp() {
        orderDao = new OrderDao();
    }
    
    @Test
    void testGetRecentOrders() {
        List<CustomerOrder> orders = orderDao.getRecentOrders();
        assertNotNull(orders);
        assertTrue(orders.size() <= 10); // Should return max 10 orders
    }
    
    @Test
    void testGetTodayOrdersCount() {
        int count = orderDao.getTodayOrdersCount();
        assertTrue(count >= 0);
    }
    
    @Test
    void testGetTodaySales() {
        BigDecimal sales = orderDao.getTodaySales();
        assertNotNull(sales);
        assertTrue(sales.compareTo(BigDecimal.ZERO) >= 0);
    }
    
    @Test
    void testGetTotalProductsCount() {
        int count = orderDao.getTotalProductsCount();
        assertTrue(count >= 0);
    }
    
    @Test
    void testGetTotalCustomersCount() {
        int count = orderDao.getTotalCustomersCount();
        assertTrue(count >= 0);
    }
    
    @Test
    void testCreateOrderInvalidCustomer() {
        Map<Integer, CartItem> emptyCart = new HashMap<>();
        int orderId = orderDao.createOrder(-1, BigDecimal.TEN, emptyCart);
        assertEquals(0, orderId); // Should fail for invalid customer
    }
    
    @Test
    void testGetCustomerOrdersInvalidCustomer() {
        List<CustomerOrder> orders = orderDao.getCustomerOrders(-1);
        assertNotNull(orders);
        assertTrue(orders.isEmpty());
    }
    
    @Test
    void testGetOrderItemsInvalidOrder() {
        List<CartItem> items = orderDao.getOrderItems(-1);
        assertNotNull(items);
        assertTrue(items.isEmpty());
    }
}
