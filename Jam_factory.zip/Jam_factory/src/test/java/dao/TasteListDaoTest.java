package dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Product;
import java.util.List;

class TasteListDaoTest {
    
    private TasteListDao tasteListDao;
    
    @BeforeEach
    void setUp() {
        tasteListDao = new TasteListDao();
    }
    
    @Test
    void testFindProductsInTasteList() {
        List<Product> products = tasteListDao.findProductsInTasteList();
        assertNotNull(products);
    }
    
    @Test
    void testFindProductsNotInTasteList() {
        List<Product> products = tasteListDao.findProductsNotInTasteList();
        assertNotNull(products);
    }
    
    @Test
    void testIsProductInTasteListInvalidId() {
        boolean inTasteList = tasteListDao.isProductInTasteList(-1);
        assertFalse(inTasteList);
    }
    
    @Test
    void testAddToTasteListInvalidId() {
        boolean result = tasteListDao.addToTasteList(-1);
        assertFalse(result);
    }
    
    @Test
    void testRemoveFromTasteListInvalidId() {
        boolean result = tasteListDao.removeFromTasteList(-1);
        assertFalse(result);
    }
    
    @Test
    void testGetProductAverageRatingInvalidId() {
        double rating = tasteListDao.getProductAverageRating(-1);
        assertEquals(0.0, rating);
    }
    
    @Test
    void testGetProductAverageRatingValidId() {
        double rating = tasteListDao.getProductAverageRating(1);
        assertTrue(rating >= 0.0 && rating <= 5.0);
    }
}
