package dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustomerDaoTest {
    
    private CustomerDao customerDao;
    
    @BeforeEach
    void setUp() {
        customerDao = new CustomerDao();
    }
    
    @Test
    void testEmailExistsWithNonExistentEmail() {
        boolean exists = customerDao.emailExists("nonexistent@test.com");
        // This could be true or false depending on DB state
        assertNotNull(exists);
    }
    
    @Test
    void testEmailExistsWithNullEmail() {
        boolean exists = customerDao.emailExists(null);
        assertFalse(exists); // Should be false, not true
    }

    
    @Test
    void testInsertCustomerWithNullData() {
        boolean result = customerDao.insert(null, null, null, null);
        assertFalse(result);
    }
    
    @Test
    void testInsertCustomerWithValidData() {
        String testEmail = "test" + System.currentTimeMillis() + "@test.com";
        boolean result = customerDao.insert(
            "Test Company",
            "12345678901",
            testEmail,
            "password123"
        );
        
        // Result depends on whether email already exists
        assertNotNull(result);
    }
}
