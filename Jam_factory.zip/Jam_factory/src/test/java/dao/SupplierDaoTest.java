package dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Supplier;
import java.util.List;

class SupplierDaoTest {
    
    private SupplierDao supplierDao;
    
    @BeforeEach
    void setUp() {
        supplierDao = new SupplierDao();
    }
    
    @Test
    void testFindAll() {
        List<Supplier> suppliers = supplierDao.findAll();
        assertNotNull(suppliers);
    }
    
    @Test
    void testFindByIdInvalidId() {
        Supplier supplier = supplierDao.findById(-1);
        assertNull(supplier);
    }
    
    @Test
    void testInsertSupplier() {
        Supplier testSupplier = new Supplier(
            "Test Supplier SRL",
            "12345678901",
            "Fragole"
        );
        
        int generatedId = supplierDao.insert(testSupplier);
        
        if (generatedId > 0) {
            assertTrue(testSupplier.getId() > 0);
            
            // Verify the supplier was inserted
            Supplier foundSupplier = supplierDao.findById(generatedId);
            assertNotNull(foundSupplier);
            assertEquals(testSupplier.getRagioneSociale(), foundSupplier.getRagioneSociale());
            
            // Clean up
            supplierDao.delete(generatedId);
        }
    }
    
    @Test
    void testUpdateSupplierInvalidId() {
        Supplier invalidSupplier = new Supplier(-1, "Test", "123", "Test Material");
        boolean result = supplierDao.update(invalidSupplier);
        assertFalse(result);
    }
    
    @Test
    void testDeleteInvalidId() {
        boolean result = supplierDao.delete(-1);
        assertFalse(result);
    }
}
