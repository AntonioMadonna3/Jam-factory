package dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.RawMaterialOrder;
import java.math.BigDecimal;
import java.util.List;

class RawMaterialOrderDaoTest {
    
    private RawMaterialOrderDao rawMaterialOrderDao;
    
    @BeforeEach
    void setUp() {
        rawMaterialOrderDao = new RawMaterialOrderDao();
    }
    
    @Test
    void testFindAll() {
        List<RawMaterialOrder> orders = rawMaterialOrderDao.findAll();
        assertNotNull(orders);
        
        // Verify that returned orders have required fields
        for (RawMaterialOrder order : orders) {
            assertTrue(order.getId() > 0);
            assertTrue(order.getSupplierId() > 0);
            assertNotNull(order.getQtyKg());
            assertTrue(order.getQtyKg().compareTo(BigDecimal.ZERO) > 0);
            assertNotNull(order.getOrderedAt());
            // Joined fields from supplier table
            assertNotNull(order.getSupplierName());
            assertNotNull(order.getMateriaPrima());
        }
    }
    
    @Test
    void testInsertOrder() {
        // Note: This test assumes supplier with ID 1 exists
        // In a real test environment, you'd want to create test data first
        RawMaterialOrder order = new RawMaterialOrder(1, new BigDecimal("25.50"));
        
        int insertedId = rawMaterialOrderDao.insert(order);
        assertTrue(insertedId > 0);
        assertEquals(insertedId, order.getId());
    }
    
    @Test
    void testInsertOrderWithConstructor() {
        BigDecimal quantity = new BigDecimal("100.75");
        RawMaterialOrder order = new RawMaterialOrder(1, quantity);
        
        int insertedId = rawMaterialOrderDao.insert(order);
        assertTrue(insertedId > 0);
        
        // Verify the order appears in findAll
        List<RawMaterialOrder> orders = rawMaterialOrderDao.findAll();
        RawMaterialOrder foundOrder = orders.stream()
            .filter(o -> o.getId() == insertedId)
            .findFirst()
            .orElse(null);
        
        assertNotNull(foundOrder);
        assertEquals(1, foundOrder.getSupplierId());
        assertEquals(quantity, foundOrder.getQtyKg());
        assertNotNull(foundOrder.getOrderedAt());
    }
    
    @Test
    void testDeleteOrder() {
        // First insert an order
        RawMaterialOrder order = new RawMaterialOrder(1, new BigDecimal("50.00"));
        int insertedId = rawMaterialOrderDao.insert(order);
        assertTrue(insertedId > 0);
        
        // Verify it exists
        List<RawMaterialOrder> ordersBefore = rawMaterialOrderDao.findAll();
        long countBefore = ordersBefore.stream()
            .filter(o -> o.getId() == insertedId)
            .count();
        assertEquals(1, countBefore);
        
        // Delete the order
        boolean deleted = rawMaterialOrderDao.delete(insertedId);
        assertTrue(deleted);
        
        // Verify it's gone
        List<RawMaterialOrder> ordersAfter = rawMaterialOrderDao.findAll();
        long countAfter = ordersAfter.stream()
            .filter(o -> o.getId() == insertedId)
            .count();
        assertEquals(0, countAfter);
    }
    
    @Test
    void testDeleteNonExistentOrder() {
        boolean deleted = rawMaterialOrderDao.delete(99999);
        assertFalse(deleted);
    }
    
    @Test
    void testInsertWithInvalidSupplierId() {
        // Test with non-existent supplier ID
        RawMaterialOrder order = new RawMaterialOrder(99999, new BigDecimal("10.00"));
        int result = rawMaterialOrderDao.insert(order);
        assertEquals(0, result);
    }
    
    @Test
    void testInsertWithNegativeQuantity() {
        RawMaterialOrder order = new RawMaterialOrder(1, new BigDecimal("-10.00"));
        int result = rawMaterialOrderDao.insert(order);
        // Depending on business logic, this might succeed or fail
        // Adjust assertion based on your requirements
        assertTrue(result >= 0);
    }
    
    @Test
    void testOrdersAreSortedByDate() {
        List<RawMaterialOrder> orders = rawMaterialOrderDao.findAll();
        
        if (orders.size() > 1) {
            // Verify orders are sorted by ordered_at DESC
            for (int i = 0; i < orders.size() - 1; i++) {
                assertTrue(
                    orders.get(i).getOrderedAt().compareTo(orders.get(i + 1).getOrderedAt()) >= 0,
                    "Orders should be sorted by date in descending order"
                );
            }
        }
    }
}
