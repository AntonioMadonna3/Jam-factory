package dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Employee;
import java.util.List;

class EmployeeDaoTest {
    
    private EmployeeDao employeeDao;
    
    @BeforeEach
    void setUp() {
        employeeDao = new EmployeeDao();
    }
    
    @Test
    void testEmailExists() {
        // Test with a non-existent email
        assertFalse(employeeDao.emailExists("nonexistent@test.com"));
    }
    
    @Test
    void testInsertEmployee() {
        String uniqueEmail = "test" + System.currentTimeMillis() + "@test.com";
        Employee employee = new Employee("Mario", "Rossi", uniqueEmail, "password123");
        
        int insertedId = employeeDao.insert(employee);
        assertTrue(insertedId > 0);
        assertEquals(insertedId, employee.getId());
        
        // Verify email now exists
        assertTrue(employeeDao.emailExists(uniqueEmail));
    }
    
    @Test
    void testInsertEmployeeWithExistingEmail() {
        String email = "duplicate@test.com";
        Employee employee1 = new Employee("Mario", "Rossi", email, "password123");
        Employee employee2 = new Employee("Luigi", "Verdi", email, "password456");
        
        // First insert should succeed
        int firstId = employeeDao.insert(employee1);
        assertTrue(firstId > 0);
        
        // Second insert with same email should fail
        int secondId = employeeDao.insert(employee2);
        assertEquals(0, secondId);
    }
    
    @Test
    void testFindAll() {
        List<Employee> employees = employeeDao.findAll();
        assertNotNull(employees);
        
        // Verify that returned employees have required fields
        for (Employee emp : employees) {
            assertTrue(emp.getId() > 0);
            assertNotNull(emp.getNome());
            assertNotNull(emp.getCognome());
            assertNotNull(emp.getEmail());
            // Password should not be returned in findAll
            assertNull(emp.getPassword());
        }
    }
    
    @Test
    void testInsertAndFindAll() {
        int initialCount = employeeDao.findAll().size();
        
        String uniqueEmail = "findall" + System.currentTimeMillis() + "@test.com";
        Employee newEmployee = new Employee("Test", "User", uniqueEmail, "testpass");
        
        int insertedId = employeeDao.insert(newEmployee);
        assertTrue(insertedId > 0);
        
        List<Employee> employees = employeeDao.findAll();
        assertEquals(initialCount + 1, employees.size());
        
        // Find the inserted employee
        Employee foundEmployee = employees.stream()
            .filter(emp -> emp.getId() == insertedId)
            .findFirst()
            .orElse(null);
        
        assertNotNull(foundEmployee);
        assertEquals("Test", foundEmployee.getNome());
        assertEquals("User", foundEmployee.getCognome());
        assertEquals(uniqueEmail, foundEmployee.getEmail());
    }
    
    @Test
    void testInsertWithNullValues() {
        Employee employee = new Employee(null, "Rossi", "null@test.com", "password");
        int result = employeeDao.insert(employee);
        assertEquals(0, result);
    }
}
