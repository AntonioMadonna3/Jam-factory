package dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Product;
import java.math.BigDecimal;
import java.util.List;

class ProductDaoTest {
    
    private ProductDao productDao;
    
    @BeforeEach
    void setUp() {
        productDao = new ProductDao();
    }
    
    @Test
    void testFindAll() {
        List<Product> products = productDao.findAll();
        assertNotNull(products);
        // Products list can be empty or contain items
    }
    
    @Test
    void testFindShopProducts() {
        List<Product> shopProducts = productDao.findShopProducts();
        assertNotNull(shopProducts);
    }
    
    @Test
    void testFindProductsNotInTasteList() {
        List<Product> products = productDao.findProductsNotInTasteList();
        assertNotNull(products);
    }
    
    @Test
    void testInsertProduct() {
        Product testProduct = new Product(
            "Test Marmellata",
            "Marmellata di test per unit test",
            new BigDecimal("5.99")
        );
        
        int generatedId = productDao.insert(testProduct);
        
        if (generatedId > 0) {
            assertTrue(testProduct.getId() > 0);
            
            // Clean up - delete the test product
            productDao.delete(generatedId);
        }
    }
    
    @Test
    void testFindById() {
        // First, get all products to find a valid ID
        List<Product> products = productDao.findAll();
        
        if (!products.isEmpty()) {
            Product firstProduct = products.get(0);
            Product foundProduct = productDao.findById(firstProduct.getId());
            
            assertNotNull(foundProduct);
            assertEquals(firstProduct.getId(), foundProduct.getId());
            assertEquals(firstProduct.getNome(), foundProduct.getNome());
        }
    }
    
    @Test
    void testFindByIdInvalidId() {
        Product product = productDao.findById(-1);
        assertNull(product);
    }
    
    @Test
    void testGetCurrentStock() {
        List<Product> products = productDao.findAll();
        
        if (!products.isEmpty()) {
            Product firstProduct = products.get(0);
            int stock = productDao.getCurrentStock(firstProduct.getId());
            assertTrue(stock >= 0);
        }
    }
    
    @Test
    void testAddStock() {
        List<Product> products = productDao.findAll();
        
        if (!products.isEmpty()) {
            Product firstProduct = products.get(0);
            int initialStock = productDao.getCurrentStock(firstProduct.getId());
            
            boolean result = productDao.addStock(firstProduct.getId(), 5);
            
            if (result) {
                int newStock = productDao.getCurrentStock(firstProduct.getId());
                assertEquals(initialStock + 5, newStock);
                
                // Clean up - remove the added stock
                productDao.addStock(firstProduct.getId(), -5);
            }
        }
    }
}
