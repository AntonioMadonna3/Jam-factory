package dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.User;
import model.User.Role;

class UserDaoTest {
    
    private UserDao userDao;
    
    @BeforeEach
    void setUp() {
        userDao = new UserDao();
    }
    
    @Test
    void testAuthenticateValidAdmin() {
        // Test with valid admin credentials
        User user = userDao.authenticate("admin@test.com", "password");
        
        if (user != null) {
            assertEquals(Role.ADMIN, user.getRole());
            assertEquals("admin@test.com", user.getEmail());
            assertTrue(user.getId() > 0);
        }
    }
    
    @Test
    void testAuthenticateValidCustomer() {
        // Test with valid customer credentials
        User user = userDao.authenticate("customer@test.com", "password");
        
        if (user != null) {
            assertEquals(Role.CLIENT, user.getRole());
            assertEquals("customer@test.com", user.getEmail());
            assertTrue(user.getId() > 0);
        }
    }
    
    @Test
    void testAuthenticateValidEmployee() {
        // Test with valid employee credentials
        User user = userDao.authenticate("employee@test.com", "password");
        
        if (user != null) {
            assertEquals(Role.EMPLOYEE, user.getRole());
            assertEquals("employee@test.com", user.getEmail());
            assertTrue(user.getId() > 0);
        }
    }
    
    @Test
    void testAuthenticateInvalidCredentials() {
        User user = userDao.authenticate("invalid@test.com", "wrongpassword");
        assertNull(user);
    }
    
    @Test
    void testAuthenticateNullEmail() {
        User user = userDao.authenticate(null, "password");
        assertNull(user);
    }
    
    @Test
    void testAuthenticateNullPassword() {
        User user = userDao.authenticate("test@test.com", null);
        assertNull(user);
    }
}
