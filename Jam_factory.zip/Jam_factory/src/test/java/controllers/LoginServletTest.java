package controllers;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import dao.UserDao;
import model.User;
import model.User.Role;

class LoginServletTest {

    private LoginServlet servlet;
    private UserDao userDao;

    @BeforeEach
    void setUp() throws Exception {
        servlet = new LoginServlet();
        servlet.init();
        userDao = new UserDao();
    }

    @Test
    void testAuthenticate_NullCredentials() {
        User result = userDao.authenticate(null, null);
        assertNull(result);
    }

    @Test
    void testAuthenticate_EmptyCredentials() {
        User result = userDao.authenticate("", "");
        assertNull(result);
    }

    @Test
    void testAuthenticate_InvalidCredentials() {
        User result = userDao.authenticate("invalid@test.com", "wrongpassword");
        assertNull(result);
    }

    @Test
    void testUserRoles() {
        // Test Role enum
        assertEquals("ADMIN", Role.ADMIN.toString());
        assertEquals("CLIENT", Role.CLIENT.toString());
        assertEquals("EMPLOYEE", Role.EMPLOYEE.toString());
    }

    @Test
    void testUserCreation() {
        User user = new User(1, "test@test.com", "Test User", Role.CLIENT);
        
        assertEquals(1, user.getId());
        assertEquals("test@test.com", user.getEmail());
        assertEquals("Test User", user.getFirstName());
        assertEquals(Role.CLIENT, user.getRole());
    }
}
