package controllers;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import dao.EmployeeDao;
import model.Employee;

class EmployeeRegisterServletTest {

    private EmployeeRegisterServlet servlet;
    private EmployeeDao employeeDao;

    @BeforeEach
    void setUp() throws Exception {
        servlet = new EmployeeRegisterServlet();
        servlet.init();
        employeeDao = new EmployeeDao();
    }

    @Test
    void testServletInitialization() {
        assertNotNull(servlet);
    }

    @Test
    void testEmployeeDao_EmailExists_WithNullEmail() {
        // Test with null email - should return true for safety
        boolean result = employeeDao.emailExists(null);
        assertTrue(result);
    }

    @Test
    void testEmployeeDao_EmailExists_WithEmptyEmail() {
        // Test with empty email - should return true for safety  
        boolean result = employeeDao.emailExists("");
        assertTrue(result);
    }

    @Test
    void testEmployeeDao_FindAll_ReturnsListOfEmployees() {
        var employees = employeeDao.findAll();
        assertNotNull(employees);
        // List può essere vuota se non ci sono dipendenti nel DB di test
    }

    @Test
    void testEmployee_Creation_WithAllParameters() {
        Employee employee = new Employee("Mario", "Rossi", "mario@test.com", "password123");
        
        assertEquals("Mario", employee.getNome());
        assertEquals("Rossi", employee.getCognome());
        assertEquals("mario@test.com", employee.getEmail());
        assertEquals("password123", employee.getPassword());
        assertEquals(0, employee.getId()); // default value before insertion
    }

    @Test
    void testEmployee_Creation_WithoutPassword() {
        Employee employee = new Employee(1, "Luigi", "Verdi", "luigi@test.com");
        
        assertEquals(1, employee.getId());
        assertEquals("Luigi", employee.getNome());
        assertEquals("Verdi", employee.getCognome());
        assertEquals("luigi@test.com", employee.getEmail());
        assertNull(employee.getPassword());
    }

    @Test
    void testEmployee_SetId() {
        Employee employee = new Employee("Test", "User", "test@test.com", "password");
        
        employee.setId(42);
        
        assertEquals(42, employee.getId());
    }

    @Test
    void testValidation_ValidEmployeeData() {
        // Test data validation logic similar to servlet
        String nome = "Mario";
        String cognome = "Rossi";
        String email = "mario@test.com";
        String password = "password123";
        String password2 = "password123";
        
        // Simulate servlet validation logic
        boolean invalid = nome == null || nome.isBlank() ||
                         cognome == null || cognome.isBlank() ||
                         email == null || !email.contains("@") ||
                         password == null || password.length() < 4 || !password.equals(password2);
        
        assertFalse(invalid);
    }

    @Test
    void testValidation_InvalidNome() {
        String nome = "";  // invalid
        String cognome = "Rossi";
        String email = "mario@test.com";
        String password = "password123";
        String password2 = "password123";
        
        boolean invalid = nome == null || nome.isBlank() ||
                         cognome == null || cognome.isBlank() ||
                         email == null || !email.contains("@") ||
                         password == null || password.length() < 4 || !password.equals(password2);
        
        assertTrue(invalid);
    }

    @Test
    void testValidation_InvalidCognome() {
        String nome = "Mario";
        String cognome = null;  // invalid
        String email = "mario@test.com";
        String password = "password123";
        String password2 = "password123";
        
        boolean invalid = nome == null || nome.isBlank() ||
                         cognome == null || cognome.isBlank() ||
                         email == null || !email.contains("@") ||
                         password == null || password.length() < 4 || !password.equals(password2);
        
        assertTrue(invalid);
    }

    @Test
    void testValidation_InvalidEmail() {
        String nome = "Mario";
        String cognome = "Rossi";
        String email = "invalid-email";  // no @ symbol
        String password = "password123";
        String password2 = "password123";
        
        boolean invalid = nome == null || nome.isBlank() ||
                         cognome == null || cognome.isBlank() ||
                         email == null || !email.contains("@") ||
                         password == null || password.length() < 4 || !password.equals(password2);
        
        assertTrue(invalid);
    }

    @Test
    void testValidation_PasswordTooShort() {
        String nome = "Mario";
        String cognome = "Rossi";
        String email = "mario@test.com";
        String password = "123";  // too short (< 4 chars)
        String password2 = "123";
        
        boolean invalid = nome == null || nome.isBlank() ||
                         cognome == null || cognome.isBlank() ||
                         email == null || !email.contains("@") ||
                         password == null || password.length() < 4 || !password.equals(password2);
        
        assertTrue(invalid);
    }

    @Test
    void testValidation_PasswordMismatch() {
        String nome = "Mario";
        String cognome = "Rossi";
        String email = "mario@test.com";
        String password = "password123";
        String password2 = "different";  // passwords don't match
        
        boolean invalid = nome == null || nome.isBlank() ||
                         cognome == null || cognome.isBlank() ||
                         email == null || !email.contains("@") ||
                         password == null || password.length() < 4 || !password.equals(password2);
        
        assertTrue(invalid);
    }

    @Test
    void testValidation_NullEmail() {
        String nome = "Mario";
        String cognome = "Rossi";
        String email = null;  // null email
        String password = "password123";
        String password2 = "password123";
        
        boolean invalid = nome == null || nome.isBlank() ||
                         cognome == null || cognome.isBlank() ||
                         email == null || !email.contains("@") ||
                         password == null || password.length() < 4 || !password.equals(password2);
        
        assertTrue(invalid);
    }

    @Test
    void testValidation_NullPassword() {
        String nome = "Mario";
        String cognome = "Rossi";
        String email = "mario@test.com";
        String password = null;  // null password
        String password2 = "password123";
        
        boolean invalid = nome == null || nome.isBlank() ||
                         cognome == null || cognome.isBlank() ||
                         email == null || !email.contains("@") ||
                         password == null || password.length() < 4 || !password.equals(password2);
        
        assertTrue(invalid);
    }

    @Test
    void testEmployeeDao_Insert_ReturnsGeneratedId() {
        // This test would work with a test database
        Employee employee = new Employee("TestUser", "TestSurname", "testuser@example.com", "testpassword");
        
        assertNotNull(employee);
        assertEquals("TestUser", employee.getNome());
        assertEquals("TestSurname", employee.getCognome());
        assertEquals("testuser@example.com", employee.getEmail());
        assertEquals("testpassword", employee.getPassword());
        assertEquals(0, employee.getId()); // Before insertion
        
        // The actual insert would require database connection
        // int generatedId = employeeDao.insert(employee);
        // assertTrue(generatedId > 0);
        // assertEquals(generatedId, employee.getId());
    }

    @Test
    void testBlankStringValidation() {
        // Test various blank string scenarios
        assertTrue("".isBlank());
        assertTrue("   ".isBlank());
        assertTrue("\t\n".isBlank());
        assertFalse("a".isBlank());
        assertFalse(" a ".isBlank());
    }

    @Test
    void testEmailValidation() {
        // Test basic email validation logic used in servlet
        assertTrue("test@example.com".contains("@"));
        assertTrue("user@domain.org".contains("@"));
        assertFalse("invalid-email".contains("@"));
        assertFalse("test.com".contains("@"));
        assertFalse("@domain.com".contains("@")); // technically contains @ but not valid
    }
}