package dao;

import model.User;
import model.User.Role;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Classe DAO (Data Access Object) per la gestione degli utenti.
 * Implementa un approccio semplificato utilizzando DriverManager direttamente,
 * appropriato per progetti didattici/d'esame.
 * 
 * Caratteristiche principali:
 * - Gestisce l'autenticazione per tre tipologie di utenti: admins, customers, employees
 * - Utilizza una query UNION per cercare in tutte e tre le tabelle simultaneamente
 * - Mappa i risultati in oggetti User con ruoli appropriati
 */
public class UserDao {

    // Configurazione per la connessione al database MySQL
    // URL di connessione con parametri per sicurezza e encoding
    private static final String JDBC_URL  = "jdbc:mysql://localhost:3306/jam_factory?useSSL=false&characterEncoding=UTF-8";
    private static final String DB_USER   = "root";      // Nome utente del database
    private static final String DB_PASS   = "password";  // Password del database

    /**
     * Query UNION per l'autenticazione utenti.
     * Effettua la ricerca simultanea in tre tabelle diverse:
     * 1. admins: cerca amministratori con campo 'nome'
     * 2. customers: cerca clienti con campo 'ragione_sociale' (mappato come first_name)
     * 3. employees: cerca dipendenti con campo 'nome'
     * 
     * Ogni SELECT richiede due parametri: email e password
     * La query restituisce al massimo un risultato (LIMIT 1)
     */
    private static final String AUTH_QUERY =
        "SELECT id, email, nome          AS first_name, 'ADMIN'    AS ruolo FROM admins    WHERE email=? AND password=? " +
        "UNION ALL " +
        "SELECT id, email, ragione_sociale AS first_name, 'CLIENT'   AS ruolo FROM customers WHERE email=? AND password=? " +
        "UNION ALL " +
        "SELECT id, email, nome          AS first_name, 'EMPLOYEE' AS ruolo FROM employees WHERE email=? AND password=? " +
        "LIMIT 1";

    /**
     * Metodo per l'autenticazione degli utenti.
     * Verifica le credenziali (email e password) contro tutte le tabelle utenti.
     * 
     * @param email    L'indirizzo email dell'utente
     * @param password La password dell'utente
     * @return Un oggetto User se l'autenticazione ha successo, null altrimenti
     * 
     * Processo di autenticazione:
     * 1. Registra il driver MySQL
     * 2. Stabilisce la connessione al database
     * 3. Prepara ed esegue la query UNION con i parametri forniti
     * 4. Se trova un match, costruisce e restituisce un oggetto User
     * 5. Gestisce eventuali errori SQL restituendo null
     */
    public User authenticate(String email, String password) {
        
        // Registrazione esplicita del driver MySQL JDBC
        // Necessaria per garantire che il driver sia disponibile
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("MySQL driver mancante", e);
        }
        
        // Utilizzo del pattern try-with-resources per gestione automatica delle risorse
        try (Connection con = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = con.prepareStatement(AUTH_QUERY)) {

            // Impostazione dei parametri per la query UNION
            // Ogni coppia (email, password) viene impostata per ciascuna delle tre SELECT
            ps.setString(1, email);  ps.setString(2, password); // Parametri per admins
            ps.setString(3, email);  ps.setString(4, password); // Parametri per customers  
            ps.setString(5, email);  ps.setString(6, password); // Parametri per employees

            // Esecuzione della query e gestione del risultato
            try (ResultSet rs = ps.executeQuery()) {
                // Se non ci sono risultati, l'autenticazione fallisce
                if (!rs.next()) return null;

                // Estrazione dei dati dal ResultSet
                int id           = rs.getInt("id");           // ID univoco dell'utente
                String eMail     = rs.getString("email");     // Email dell'utente
                String firstName = rs.getString("first_name"); // Nome o ragione sociale
                Role role        = Role.valueOf(rs.getString("ruolo")); // Ruolo convertito in enum

                // Creazione e restituzione dell'oggetto User autenticato
                return new User(id, eMail, firstName, role);
            }
        } catch (SQLException e) {
            // Gestione degli errori SQL con stampa dello stack trace
            // Approccio adeguato per progetti didattici
            e.printStackTrace();
            return null; // Restituisce null in caso di errore
        }
    }

}
