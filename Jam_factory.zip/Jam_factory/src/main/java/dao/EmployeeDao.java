package dao;

import model.Employee;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * EmployeeDao - Classe DAO (Data Access Object) per la gestione della tabella employees
 * nel database MySQL utilizzando JDBC puro senza framework ORM.
 * Fornisce operazioni CRUD di base per l'entità Employee.
 */
public class EmployeeDao {

    // Configurazione connessione database MySQL
    private static final String JDBC_URL  = "jdbc:mysql://localhost:3306/jam_factory?useSSL=false&characterEncoding=UTF-8";
    private static final String DB_USER   = "root";
    private static final String DB_PASS   = "password";

    // Query SQL preparate per le operazioni sulla tabella employees
    private static final String INSERT_SQL =
        "INSERT INTO employees (nome, cognome, email, password) VALUES (?,?,?,?)";

    private static final String CHECK_EMAIL_SQL =
        "SELECT 1 FROM employees WHERE email=? LIMIT 1";

    private static final String FIND_ALL_SQL =
        "SELECT id, nome, cognome, email FROM employees";

    /**
     * Verifica se esiste già un dipendente registrato con l'email specificata.
     * Utile per prevenire duplicati durante la registrazione.
     * 
     * @param email l'indirizzo email da verificare
     * @return true se l'email è già presente nel database, false altrimenti
     */
    public boolean emailExists(String email) {
        // Registrazione esplicita del driver MySQL JDBC
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("MySQL driver mancante", e);
        }
        
        // Utilizzo di try-with-resources per gestione automatica delle risorse
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(CHECK_EMAIL_SQL)) {
            
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                // Se il ResultSet contiene almeno un record, l'email esiste
                return rs.next();
            }
        } catch (SQLException e) {
            // In caso di errore SQL, restituisce true per sicurezza (comportamento prudenziale)
            return true;
        }
    }

    /**
     * Inserisce un nuovo dipendente nella tabella employees.
     * Genera automaticamente l'ID e lo assegna all'oggetto Employee.
     * 
     * @param e l'oggetto Employee da inserire
     * @return l'ID generato dal database, 0 in caso di errore
     */
    public int insert(Employee e) {
        // Registrazione esplicita del driver MySQL JDBC
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException f) {
            throw new IllegalStateException("MySQL driver mancante", f);
        }
        
        // Prepared statement con richiesta delle chiavi generate automaticamente
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS)) {
            
            // Impostazione dei parametri della query
            ps.setString(1, e.getNome());
            ps.setString(2, e.getCognome());
            ps.setString(3, e.getEmail());
            ps.setString(4, e.getPassword());

            // Esecuzione dell'inserimento e verifica che sia stata inserita esattamente una riga
            if (ps.executeUpdate() != 1) return 0;

            // Recupero dell'ID auto-generato dal database
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    int id = keys.getInt(1);
                    e.setId(id); // Aggiorna l'oggetto Employee con l'ID generato
                    return id;
                }
            }
        } catch (SQLException ex) {
            // Gestione degli errori SQL senza interrompere l'applicazione
            return 0;
        }
        return 0;
    }

    /**
     * Recupera tutti i dipendenti presenti nella tabella employees.
     * Non include la password per motivi di sicurezza.
     * 
     * @return lista di tutti gli oggetti Employee presenti nel database
     */
    public List<Employee> findAll() {
        List<Employee> list = new ArrayList<>();
        
        // Utilizzo di Statement semplice per query senza parametri
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(FIND_ALL_SQL)) {
            
            // Iterazione sui risultati e creazione degli oggetti Employee
            while (rs.next()) {
                list.add(new Employee(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("cognome"),
                    rs.getString("email")
                    // Password omessa intenzionalmente per sicurezza
                ));
            }
        } catch (SQLException e) {
            // Gestione degli errori SQL - la lista rimane vuota
        }
        return list;
    }
}
