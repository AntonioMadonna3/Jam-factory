package dao;

import model.RawMaterialOrder;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;

/**
 * Classe DAO per la gestione degli ordini di materie prime.
 * Fornisce operazioni CRUD per interagire con la tabella raw_material_orders del database.
 */
public class RawMaterialOrderDao {

    // Configurazione della connessione al database MySQL
    private static final String JDBC_URL  = "jdbc:mysql://localhost:3306/jam_factory?useSSL=false&characterEncoding=UTF-8";
    private static final String DB_USER   = "root";
    private static final String DB_PASS   = "password";

    // Query SQL per recuperare tutti gli ordini con le informazioni del fornitore
    private static final String SELECT_ALL_WITH_SUPPLIER = 
      "SELECT rmo.id, rmo.supplier_id, rmo.qty_kg, rmo.ordered_at, " +
      "s.ragione_sociale, s.materia_prima " +
      "FROM raw_material_orders rmo " +
      "JOIN suppliers s ON rmo.supplier_id = s.id " +
      "ORDER BY rmo.ordered_at DESC";

    // Query SQL per inserire un nuovo ordine
    private static final String INSERT_ORDER = 
      "INSERT INTO raw_material_orders (supplier_id, qty_kg) VALUES (?,?)";

    // Query SQL per eliminare un ordine
    private static final String DELETE_ORDER = "DELETE FROM raw_material_orders WHERE id=?";

    /**
     * Recupera tutti gli ordini di materie prime dal database con le informazioni del fornitore.
     * Gli ordini sono ordinati per data di ordinazione in ordine decrescente.
     * 
     * @return Lista di tutti gli ordini di materie prime
     */
    public List<RawMaterialOrder> findAll() {
        List<RawMaterialOrder> list = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(SELECT_ALL_WITH_SUPPLIER)) {
            while (rs.next()) {
                // Creazione dell'oggetto ordine con i dati di base
                RawMaterialOrder order = new RawMaterialOrder(
                    rs.getInt("id"),
                    rs.getInt("supplier_id"),
                    rs.getBigDecimal("qty_kg"),
                    rs.getTimestamp("ordered_at")
                );
                // Aggiunta delle informazioni del fornitore ottenute tramite JOIN
                order.setSupplierName(rs.getString("ragione_sociale"));
                order.setMateriaPrima(rs.getString("materia_prima"));
                list.add(order);
            }
        } catch (SQLException e) { 
            // Gestione degli errori SQL
        }
        return list;
    }

    /**
     * Inserisce un nuovo ordine di materie prime nel database.
     * 
     * @param order L'ordine da inserire
     * @return L'ID generato automaticamente per l'ordine inserito, 0 in caso di errore
     */
    public int insert(RawMaterialOrder order) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(INSERT_ORDER, Statement.RETURN_GENERATED_KEYS)) {
            // Impostazione dei parametri per l'inserimento
            ps.setInt(1, order.getSupplierId());
            ps.setBigDecimal(2, order.getQtyKg());
            
            if (ps.executeUpdate() == 1) {
                // Recupero dell'ID generato automaticamente
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        int id = keys.getInt(1);
                        order.setId(id);
                        return id;
                    }
                }
            }
        } catch (SQLException e) { 
            // Gestione degli errori SQL
        }
        return 0;
    }

    /**
     * Elimina un ordine di materie prime dal database.
     * 
     * @param id L'ID dell'ordine da eliminare
     * @return true se l'eliminazione è avvenuta con successo, false altrimenti
     */
    public boolean delete(int id) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(DELETE_ORDER)) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) { 
            return false; 
        }
    }
}
