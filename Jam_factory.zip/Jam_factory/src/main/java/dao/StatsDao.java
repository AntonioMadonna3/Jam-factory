package dao;

import java.sql.*;
import java.util.*;
import java.math.BigDecimal;

/**
 * Classe DAO per la gestione delle statistiche aziendali
 * Fornisce metodi per recuperare dati analitici dal database della fabbrica di marmellate
 */
public class StatsDao {
    // Configurazione connessione database
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/jam_factory?useSSL=false&characterEncoding=UTF-8";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "password";

    /**
     * Restituisce una panoramica generale delle statistiche aziendali
     * Include conteggi di prodotti, clienti, dipendenti, fornitori e attività recenti
     * @return Map contenente le statistiche di overview
     */
    public Map<String, Integer> getOverviewStats() {
        Map<String, Integer> stats = new HashMap<>();
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
            // Conta il numero totale di prodotti nel catalogo
            try (Statement st = c.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT COUNT(*) as count FROM products");
                if (rs.next()) stats.put("totalProducts", rs.getInt("count"));
            }
            
            // Conta il numero totale di clienti registrati
            try (Statement st = c.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT COUNT(*) as count FROM customers");
                if (rs.next()) stats.put("totalCustomers", rs.getInt("count"));
            }
            
            // Conta il numero totale di dipendenti
            try (Statement st = c.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT COUNT(*) as count FROM employees");
                if (rs.next()) stats.put("totalEmployees", rs.getInt("count"));
            }
            
            // Conta il numero totale di fornitori
            try (Statement st = c.createStatement()) {
                ResultSet rs = st.executeQuery("SELECT COUNT(*) as count FROM suppliers");
                if (rs.next()) stats.put("totalSuppliers", rs.getInt("count"));
            }
            
            // Conta gli ordini ricevuti nell'ultimo mese
            try (Statement st = c.createStatement()) {
                ResultSet rs = st.executeQuery(
                    "SELECT COUNT(*) as count FROM customer_orders " +
                    "WHERE ordered_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)"
                );
                if (rs.next()) stats.put("ordersLastMonth", rs.getInt("count"));
            }
            
            // Conta i feedback ricevuti nell'ultimo mese
            try (Statement st = c.createStatement()) {
                ResultSet rs = st.executeQuery(
                    "SELECT COUNT(*) as count FROM feedback " +
                    "WHERE given_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)"
                );
                if (rs.next()) stats.put("feedbackLastMonth", rs.getInt("count"));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return stats;
    }

    /**
     * Recupera i prodotti più venduti ordinati per quantità venduta
     * @param limit numero massimo di prodotti da restituire
     * @return lista dei prodotti con quantità totale venduta e ricavi
     */
    public List<Map<String, Object>> getTopSellingProducts(int limit) {
        List<Map<String, Object>> products = new ArrayList<>();
        String sql = """
            SELECT p.nome, SUM(oi.qty) as total_qty, SUM(oi.qty * oi.price_eur) as total_revenue
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            GROUP BY p.id, p.nome
            ORDER BY total_qty DESC
            LIMIT ?
            """;
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(sql)) {
            
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> product = new HashMap<>();
                product.put("nome", rs.getString("nome"));
                product.put("totalQty", rs.getInt("total_qty"));
                product.put("totalRevenue", rs.getBigDecimal("total_revenue"));
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return products;
    }

    /**
     * Recupera i prodotti meno venduti, escludendo quelli che sono gusti di altri prodotti
     * @param limit numero massimo di prodotti da restituire
     * @return lista dei prodotti con vendite più basse
     */
    public List<Map<String, Object>> getLeastSellingProducts(int limit) {
        List<Map<String, Object>> products = new ArrayList<>();
        String sql = """
            SELECT p.nome, COALESCE(SUM(oi.qty), 0) as total_qty, 
                   COALESCE(SUM(oi.qty * oi.price_eur), 0) as total_revenue
            FROM products p
            LEFT JOIN order_items oi ON p.id = oi.product_id
            LEFT JOIN taste_list tl ON p.id = tl.product_id
            WHERE tl.product_id IS NULL
            GROUP BY p.id, p.nome
            ORDER BY total_qty ASC
            LIMIT ?
            """;
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(sql)) {
            
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> product = new HashMap<>();
                product.put("nome", rs.getString("nome"));
                product.put("totalQty", rs.getInt("total_qty"));
                product.put("totalRevenue", rs.getBigDecimal("total_revenue"));
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return products;
    }

    /**
     * Recupera i fornitori ordinati per quantità di materie prime ordinate
     * Include informazioni su ragione sociale, tipo di materia prima e ultimo ordine
     * @return lista dei fornitori con statistiche aggregate
     */
    public List<Map<String, Object>> getTopSuppliers() {
        List<Map<String, Object>> suppliers = new ArrayList<>();
        String sql = """
            SELECT s.ragione_sociale, s.materia_prima, 
                   SUM(rmo.qty_kg) as total_qty, 
                   MAX(rmo.ordered_at) as last_order
            FROM suppliers s
            JOIN raw_material_orders rmo ON s.id = rmo.supplier_id
            GROUP BY s.id, s.ragione_sociale, s.materia_prima
            ORDER BY total_qty DESC
            """;
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            while (rs.next()) {
                Map<String, Object> supplier = new HashMap<>();
                supplier.put("ragioneSociale", rs.getString("ragione_sociale"));
                supplier.put("materiaPrima", rs.getString("materia_prima"));
                supplier.put("totalQty", rs.getBigDecimal("total_qty"));
                supplier.put("lastOrder", rs.getTimestamp("last_order"));
                suppliers.add(supplier);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return suppliers;
    }

    /**
     * Analizza l'andamento delle vendite mensili negli ultimi 12 mesi
     * Fornisce ricavi e numero di ordini per ogni mese
     * @return lista con dati mensili di vendita
     */
    public List<Map<String, Object>> getMonthlySales() {
        List<Map<String, Object>> sales = new ArrayList<>();
        String sql = """
            SELECT DATE_FORMAT(ordered_at, '%Y-%m') as month,
                   SUM(total_eur) as revenue,
                   COUNT(*) as orders
            FROM customer_orders
            WHERE ordered_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
            GROUP BY DATE_FORMAT(ordered_at, '%Y-%m')
            ORDER BY month ASC
            """;
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            while (rs.next()) {
                Map<String, Object> monthData = new HashMap<>();
                monthData.put("month", rs.getString("month"));
                monthData.put("revenue", rs.getBigDecimal("revenue"));
                monthData.put("orders", rs.getInt("orders"));
                sales.add(monthData);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return sales;
    }

    /**
     * Identifica i clienti migliori in base al fatturato totale generato
     * @param limit numero massimo di clienti da restituire
     * @return lista dei top clienti con totale speso e numero ordini
     */
    public List<Map<String, Object>> getTopCustomers(int limit) {
        List<Map<String, Object>> customers = new ArrayList<>();
        String sql = """
            SELECT c.ragione_sociale, c.p_iva,
                   SUM(co.total_eur) as total_spent,
                   COUNT(co.id) as total_orders
            FROM customers c
            JOIN customer_orders co ON c.id = co.customer_id
            GROUP BY c.id, c.ragione_sociale, c.p_iva
            ORDER BY total_spent DESC
            LIMIT ?
            """;
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(sql)) {
            
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> customer = new HashMap<>();
                customer.put("ragioneSociale", rs.getString("ragione_sociale"));
                customer.put("pIva", rs.getString("p_iva"));
                customer.put("totalSpent", rs.getBigDecimal("total_spent"));
                customer.put("totalOrders", rs.getInt("total_orders"));
                customers.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return customers;
    }

    /**
     * Calcola il valore medio degli ordini clienti
     * Utile per analizzare il comportamento di acquisto medio
     * @return valore medio ordine in euro
     */
    public BigDecimal getAverageOrderValue() {
        String sql = "SELECT AVG(total_eur) as avg_value FROM customer_orders";
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            if (rs.next()) {
                return rs.getBigDecimal("avg_value");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return BigDecimal.ZERO;
    }

    /**
     * Recupera i prodotti con le valutazioni più alte dai feedback clienti
     * @param limit numero massimo di prodotti da restituire
     * @return lista prodotti ordinati per rating medio decrescente
     */
    public List<Map<String, Object>> getTopRatedProducts(int limit) {
        List<Map<String, Object>> products = new ArrayList<>();
        String sql = """
            SELECT p.nome, AVG(f.rating) as avg_rating, COUNT(f.rating) as feedback_count
            FROM products p
            JOIN feedback f ON p.id = f.product_id
            GROUP BY p.id, p.nome
            HAVING feedback_count > 0
            ORDER BY avg_rating DESC, feedback_count DESC
            LIMIT ?
            """;
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(sql)) {
            
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> product = new HashMap<>();
                product.put("nome", rs.getString("nome"));
                product.put("avgRating", rs.getDouble("avg_rating"));
                product.put("feedbackCount", rs.getInt("feedback_count"));
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return products;
    }

    /**
     * Recupera i prodotti con le valutazioni più basse dai feedback clienti
     * Utile per identificare prodotti che necessitano miglioramenti
     * @param limit numero massimo di prodotti da restituire
     * @return lista prodotti ordinati per rating medio crescente
     */
    public List<Map<String, Object>> getLowestRatedProducts(int limit) {
        List<Map<String, Object>> products = new ArrayList<>();
        String sql = """
            SELECT p.nome, AVG(f.rating) as avg_rating, COUNT(f.rating) as feedback_count
            FROM products p
            JOIN feedback f ON p.id = f.product_id
            GROUP BY p.id, p.nome
            HAVING feedback_count > 0
            ORDER BY avg_rating ASC, feedback_count DESC
            LIMIT ?
            """;
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(sql)) {
            
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> product = new HashMap<>();
                product.put("nome", rs.getString("nome"));
                product.put("avgRating", rs.getDouble("avg_rating"));
                product.put("feedbackCount", rs.getInt("feedback_count"));
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return products;
    }

    /**
     * Analizza la distribuzione delle valutazioni da 1 a 5 stelle
     * Fornisce una visione d'insieme della soddisfazione clienti
     * @return mappa con conteggio per ogni livello di rating (1-5 stelle)
     */
    public Map<Integer, Integer> getRatingDistribution() {
        Map<Integer, Integer> distribution = new HashMap<>();
        String sql = "SELECT rating, COUNT(*) as count FROM feedback GROUP BY rating ORDER BY rating";
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            // Inizializza tutti i livelli di rating a 0 per garantire completezza dei dati
            for (int i = 1; i <= 5; i++) {
                distribution.put(i, 0);
            }
            
            while (rs.next()) {
                distribution.put(rs.getInt("rating"), rs.getInt("count"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return distribution;
    }

    /**
     * Recupera i prodotti che hanno ricevuto più feedback dai clienti
     * Ordinati per numero di recensioni ricevute
     * @param limit numero massimo di prodotti da restituire
     * @return lista prodotti ordinati per numero di feedback decrescente
     */
    public List<Map<String, Object>> getMostReviewedProducts(int limit) {
        List<Map<String, Object>> products = new ArrayList<>();
        String sql = """
            SELECT p.nome, COUNT(f.rating) as feedback_count, AVG(f.rating) as avg_rating
            FROM products p
            JOIN feedback f ON p.id = f.product_id
            GROUP BY p.id, p.nome
            ORDER BY feedback_count DESC, avg_rating DESC
            LIMIT ?
            """;
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(sql)) {
            
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> product = new HashMap<>();
                product.put("nome", rs.getString("nome"));
                product.put("feedbackCount", rs.getInt("feedback_count"));
                product.put("avgRating", rs.getDouble("avg_rating"));
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return products;
    }
}
