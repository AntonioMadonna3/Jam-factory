package dao;

import model.Feedback;
import model.Product;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe DAO per la gestione dei feedback dei dipendenti sui prodotti.
 * Gestisce tutte le operazioni CRUD relative alla tabella feedback nel database.
 */
public class FeedbackDao {
    // Configurazione connessione database
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/jam_factory?useSSL=false&characterEncoding=UTF-8";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "password";

    // Query SQL predefinite per ottimizzare le prestazioni
    private static final String INSERT_FEEDBACK = 
        "INSERT INTO feedback (employee_id, product_id, rating, note) VALUES (?, ?, ?, ?)";
    
    private static final String SELECT_EMPLOYEE_FEEDBACK = 
        "SELECT f.product_id, p.nome, f.rating, f.note, f.given_at " +
        "FROM feedback f INNER JOIN products p ON f.product_id = p.id " +
        "WHERE f.employee_id = ? ORDER BY f.given_at DESC";
    
    private static final String SELECT_ALL_FEEDBACK = 
        "SELECT f.employee_id, f.product_id, p.nome as product_name, " +
        "e.nome, e.cognome, f.rating, f.note, f.given_at " +
        "FROM feedback f " +
        "INNER JOIN products p ON f.product_id = p.id " +
        "INNER JOIN employees e ON f.employee_id = e.id " +
        "ORDER BY f.given_at DESC";
    
    private static final String CHECK_EXISTING_FEEDBACK = 
        "SELECT 1 FROM feedback WHERE employee_id = ? AND product_id = ?";
    
    private static final String SELECT_PRODUCTS_WITHOUT_FEEDBACK = 
        "SELECT DISTINCT p.id, p.nome, p.descrizione, p.prezzo_unit " +
        "FROM products p " +
        "INNER JOIN taste_list tl ON p.id = tl.product_id " +
        "LEFT JOIN feedback f ON (p.id = f.product_id AND f.employee_id = ?) " +
        "WHERE f.product_id IS NULL " +
        "ORDER BY p.nome";

    /**
     * Aggiunge un nuovo feedback di un dipendente per un prodotto.
     * 
     * @param employeeId ID del dipendente che lascia il feedback
     * @param productId ID del prodotto valutato
     * @param rating Valutazione numerica del prodotto
     * @param note Note testuali aggiuntive
     * @return true se l'inserimento è avvenuto con successo, false altrimenti
     */
    public boolean addFeedback(int employeeId, int productId, int rating, String note) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(INSERT_FEEDBACK)) {
            
            ps.setInt(1, employeeId);
            ps.setInt(2, productId);
            ps.setInt(3, rating);
            ps.setString(4, note);
            
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Recupera tutti i feedback lasciati da un dipendente specifico.
     * Include il nome del prodotto per ogni feedback.
     * 
     * @param employeeId ID del dipendente di cui recuperare i feedback
     * @return Lista dei feedback del dipendente, ordinati per data decrescente
     */
    public List<Feedback> getEmployeeFeedback(int employeeId) {
        List<Feedback> feedbacks = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(SELECT_EMPLOYEE_FEEDBACK)) {
            
            ps.setInt(1, employeeId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Feedback feedback = new Feedback(
                        employeeId,
                        rs.getInt("product_id"),
                        rs.getInt("rating"),
                        rs.getString("note"),
                        rs.getTimestamp("given_at")
                    );
                    feedback.setProductName(rs.getString("nome"));
                    feedbacks.add(feedback);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return feedbacks;
    }

    /**
     * Recupera tutti i feedback presenti nel sistema.
     * Include informazioni complete su dipendente e prodotto per ogni feedback.
     * 
     * @return Lista completa di tutti i feedback, ordinati per data decrescente
     */
    public List<Feedback> getAllFeedback() {
        List<Feedback> feedbacks = new ArrayList<>();
        String sql = """
            SELECT f.product_id, f.employee_id, f.rating, f.note, f.given_at,
                   p.nome as product_name, 
                   CONCAT(e.nome, ' ', e.cognome) as employee_name
            FROM feedback f
            JOIN products p ON f.product_id = p.id
            JOIN employees e ON f.employee_id = e.id
            ORDER BY f.given_at DESC
            """;
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            while (rs.next()) {
                Feedback feedback = new Feedback(
                    rs.getInt("employee_id"),
                    rs.getInt("product_id"),
                    rs.getInt("rating"),
                    rs.getString("note"),
                    rs.getTimestamp("given_at")
                );
                feedback.setProductName(rs.getString("product_name"));
                feedback.setEmployeeName(rs.getString("employee_name"));
                feedbacks.add(feedback);
            }
            
        } catch (SQLException e) {
            System.err.println("Error in getAllFeedback: " + e.getMessage());
            e.printStackTrace();
        }
        
        return feedbacks;
    }

    /**
     * Verifica se un dipendente ha già lasciato un feedback per un prodotto specifico.
     * Utilizzato per prevenire feedback duplicati.
     * 
     * @param employeeId ID del dipendente
     * @param productId ID del prodotto
     * @return true se esiste già un feedback, false altrimenti
     */
    public boolean hasEmployeeGivenFeedback(int employeeId, int productId) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(CHECK_EXISTING_FEEDBACK)) {
            
            ps.setInt(1, employeeId);
            ps.setInt(2, productId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Recupera tutti i prodotti per i quali un dipendente non ha ancora lasciato feedback.
     * Considera solo i prodotti presenti nella taste_list (prodotti disponibili per la degustazione).
     * 
     * @param employeeId ID del dipendente
     * @return Lista dei prodotti disponibili per il feedback, ordinati per nome
     */
    public List<Product> getProductsAvailableForFeedback(int employeeId) {
        List<Product> products = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(SELECT_PRODUCTS_WITHOUT_FEEDBACK)) {
            
            ps.setInt(1, employeeId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    products.add(new Product(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("descrizione"),
                        rs.getBigDecimal("prezzo_unit"),
                        0
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }
}
