package dao;

import model.Supplier;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe DAO (Data Access Object) per la gestione dei fornitori nel database.
 * Implementa le operazioni CRUD (Create, Read, Update, Delete) per l'entità Supplier.
 */
public class SupplierDao {

    // Parametri di connessione al database MySQL
    private static final String JDBC_URL  = "jdbc:mysql://localhost:3306/jam_factory?useSSL=false&characterEncoding=UTF-8";
    private static final String DB_USER   = "root";
    private static final String DB_PASS   = "password";

    // Query SQL predefinite per le operazioni sui fornitori
    private static final String SELECT_ALL = 
      "SELECT id, ragione_sociale, p_iva, materia_prima FROM suppliers ORDER BY ragione_sociale";

    private static final String INSERT_SUPPLIER = 
      "INSERT INTO suppliers (ragione_sociale, p_iva, materia_prima) VALUES (?,?,?)";

    private static final String UPDATE_SUPPLIER = 
      "UPDATE suppliers SET ragione_sociale=?, p_iva=?, materia_prima=? WHERE id=?";

    private static final String DELETE_SUPPLIER = "DELETE FROM suppliers WHERE id=?";

    private static final String SELECT_BY_ID = 
      "SELECT id, ragione_sociale, p_iva, materia_prima FROM suppliers WHERE id=?";

    /**
     * Recupera tutti i fornitori dal database ordinati per ragione sociale.
     * @return Lista di tutti i fornitori presenti nel database
     */
    public List<Supplier> findAll() {
        List<Supplier> list = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(SELECT_ALL)) {
            
            // Itera attraverso i risultati e crea oggetti Supplier
            while (rs.next()) {
                list.add(new Supplier(
                    rs.getInt("id"),
                    rs.getString("ragione_sociale"),
                    rs.getString("p_iva"),
                    rs.getString("materia_prima")
                ));
            }
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
        return list;
    }

    /**
     * Cerca un fornitore specifico tramite il suo ID.
     * @param id L'identificativo univoco del fornitore
     * @return Il fornitore trovato oppure null se non esiste
     */
    public Supplier findById(int id) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(SELECT_BY_ID)) {
            
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Supplier(
                        rs.getInt("id"),
                        rs.getString("ragione_sociale"),
                        rs.getString("p_iva"),
                        rs.getString("materia_prima")
                    );
                }
            }
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
        return null;
    }

    /**
     * Inserisce un nuovo fornitore nel database.
     * @param s L'oggetto Supplier da inserire
     * @return L'ID generato automaticamente dal database, 0 se l'inserimento fallisce
     */
    public int insert(Supplier s) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(INSERT_SUPPLIER, Statement.RETURN_GENERATED_KEYS)) {
            
            // Imposta i parametri della query
            ps.setString(1, s.getRagioneSociale());
            ps.setString(2, s.getPIva());
            ps.setString(3, s.getMateriaPrima());
            
            // Esegue l'inserimento e recupera l'ID generato
            if (ps.executeUpdate() == 1) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        int id = keys.getInt(1);
                        s.setId(id); // Aggiorna l'oggetto con l'ID generato
                        return id;
                    }
                }
            }
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
        return 0;
    }

    /**
     * Aggiorna un fornitore esistente nel database.
     * @param s L'oggetto Supplier con i dati aggiornati
     * @return true se l'aggiornamento è andato a buon fine, false altrimenti
     */
    public boolean update(Supplier s) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(UPDATE_SUPPLIER)) {
            
            // Imposta i parametri per l'aggiornamento
            ps.setString(1, s.getRagioneSociale());
            ps.setString(2, s.getPIva());
            ps.setString(3, s.getMateriaPrima());
            ps.setInt(4, s.getId());
            
            return ps.executeUpdate() == 1;
        } catch (SQLException e) { 
            e.printStackTrace(); 
            return false; 
        }
    }

    /**
     * Elimina un fornitore dal database tramite il suo ID.
     * @param id L'identificativo del fornitore da eliminare
     * @return true se l'eliminazione è riuscita, false altrimenti
     */
    public boolean delete(int id) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(DELETE_SUPPLIER)) {
            
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) { 
            e.printStackTrace(); 
            return false; 
        }
    }
}
