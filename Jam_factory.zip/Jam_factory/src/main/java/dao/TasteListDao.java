package dao;

import model.Product;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe DAO per la gestione della taste list (lista dei gusti).
 * Fornisce metodi per gestire i prodotti selezionati per degustazioni
 * e per ottenere informazioni sui feedback dei prodotti.
 */
public class TasteListDao {

    // Configurazione della connessione al database MySQL
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/jam_factory?useSSL=false&characterEncoding=UTF-8";
    private static final String DB_USER  = "root";
    private static final String DB_PASS  = "password";

    // Query per selezionare tutti i prodotti presenti nella taste list
    private static final String SELECT_IN_TASTE_LIST = 
        "SELECT p.id, p.nome, p.descrizione, p.prezzo_unit " +
        "FROM products p INNER JOIN taste_list tl ON p.id = tl.product_id " +
        "ORDER BY p.nome";

    // Query per selezionare tutti i prodotti NON presenti nella taste list
    private static final String SELECT_NOT_IN_TASTE_LIST = 
        "SELECT p.id, p.nome, p.descrizione, p.prezzo_unit " +
        "FROM products p LEFT JOIN taste_list tl ON p.id = tl.product_id " +
        "WHERE tl.product_id IS NULL " +
        "ORDER BY p.nome";

    // Query per verificare se un prodotto è già presente nella taste list
    private static final String CHECK_IN_TASTE_LIST = 
        "SELECT 1 FROM taste_list WHERE product_id = ?";

    // Query per inserire un nuovo prodotto nella taste list
    private static final String INSERT_TASTE_LIST = 
        "INSERT INTO taste_list (product_id) VALUES (?)";

    // Query per rimuovere un prodotto dalla taste list
    private static final String DELETE_TASTE_LIST = 
        "DELETE FROM taste_list WHERE product_id = ?";

    // Query per calcolare la media delle valutazioni di un prodotto dai feedback
    private static final String GET_PRODUCT_AVERAGE_RATING = 
        "SELECT COALESCE(AVG(f.rating), 0) as avg_rating " +
        "FROM feedback f WHERE f.product_id = ?";

    /**
     * Recupera tutti i prodotti che sono attualmente nella taste list.
     * Utilizza una JOIN tra le tabelle products e taste_list per ottenere
     * solo i prodotti selezionati per le degustazioni.
     * 
     * @return Lista dei prodotti nella taste list, ordinati per nome
     */
    public List<Product> findProductsInTasteList() {
        List<Product> products = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(SELECT_IN_TASTE_LIST)) {

            while (rs.next()) {
                products.add(new Product(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("descrizione"),
                    rs.getBigDecimal("prezzo_unit"),
                    0 // Lo stock non è rilevante per la taste list
                ));
            }
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
        return products;
    }

    /**
     * Recupera tutti i prodotti che NON sono nella taste list.
     * Utilizza una LEFT JOIN per identificare i prodotti che non hanno
     * una corrispondenza nella tabella taste_list.
     * 
     * @return Lista dei prodotti non presenti nella taste list, ordinati per nome
     */
    public List<Product> findProductsNotInTasteList() {
        List<Product> products = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(SELECT_NOT_IN_TASTE_LIST)) {

            while (rs.next()) {
                products.add(new Product(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("descrizione"),
                    rs.getBigDecimal("prezzo_unit"),
                    0 // Lo stock non è rilevante per la taste list
                ));
            }
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
        return products;
    }

    /**
     * Verifica se un prodotto specifico è già presente nella taste list.
     * Utile per evitare duplicati prima di aggiungere un nuovo prodotto.
     * 
     * @param productId ID del prodotto da verificare
     * @return true se il prodotto è nella taste list, false altrimenti
     */
    public boolean isProductInTasteList(int productId) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(CHECK_IN_TASTE_LIST)) {

            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next(); // Ritorna true se trova almeno un record
            }
        } catch (SQLException e) { 
            e.printStackTrace(); 
            return false;
        }
    }

    /**
     * Aggiunge un prodotto alla taste list.
     * Il prodotto viene inserito nella tabella taste_list per renderlo
     * disponibile per le degustazioni.
     * 
     * @param productId ID del prodotto da aggiungere
     * @return true se l'inserimento è avvenuto con successo, false altrimenti
     */
    public boolean addToTasteList(int productId) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(INSERT_TASTE_LIST)) {

            ps.setInt(1, productId);
            return ps.executeUpdate() == 1; // Verifica che sia stata modificata esattamente una riga
        } catch (SQLException e) { 
            e.printStackTrace(); 
            return false;
        }
    }

    /**
     * Rimuove un prodotto dalla taste list.
     * Il prodotto non sarà più disponibile per le degustazioni una volta rimosso.
     * 
     * @param productId ID del prodotto da rimuovere
     * @return true se la rimozione è avvenuta con successo, false altrimenti
     */
    public boolean removeFromTasteList(int productId) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(DELETE_TASTE_LIST)) {

            ps.setInt(1, productId);
            return ps.executeUpdate() == 1; // Verifica che sia stata modificata esattamente una riga
        } catch (SQLException e) { 
            e.printStackTrace(); 
            return false;
        }
    }

    /**
     * Calcola la media delle valutazioni (rating) per un prodotto specifico.
     * Analizza tutti i feedback ricevuti per il prodotto e ne calcola la media.
     * Se non ci sono feedback, ritorna 0.0 grazie alla funzione COALESCE.
     * 
     * @param productId ID del prodotto per cui calcolare la media
     * @return Media delle valutazioni del prodotto (0.0 se nessun feedback)
     */
    public double getProductAverageRating(int productId) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(GET_PRODUCT_AVERAGE_RATING)) {

            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("avg_rating");
                }
            }
        } catch (SQLException e) { 
            e.printStackTrace();
        }
        return 0.0; // Valore di default in caso di errore
    }
}
