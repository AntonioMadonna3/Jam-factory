package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Data Access Object per la gestione dei clienti nel database.
 * Fornisce operazioni per l'inserimento e la verifica dell'esistenza dei clienti.
 */
public class CustomerDao {

    // Configurazione connessione database MySQL
    private static final String JDBC_URL  = "jdbc:mysql://localhost:3306/jam_factory?useSSL=false&characterEncoding=UTF-8";
    private static final String DB_USER   = "root";
    private static final String DB_PASS   = "password";

    // Query SQL per l'inserimento di un nuovo cliente
    private static final String INSERT_SQL =
      "INSERT INTO customers (ragione_sociale, p_iva, email, password) VALUES (?,?,?,?)";

    // Query SQL per verificare l'esistenza di un'email
    private static final String CHECK_EMAIL_SQL =
      "SELECT 1 FROM customers WHERE email=? LIMIT 1";

    /**
     * Verifica se un'email esiste già nel database.
     * 
     * @param email l'indirizzo email da verificare
     * @return true se l'email esiste, false altrimenti
     */
    public boolean emailExists(String email) {
        // Controllo parametro di input
        if (email == null) {
            return false;
        }
        
        // Caricamento del driver MySQL
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("MySQL driver mancante", e);
        }
        
        // Esecuzione della query di verifica
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(CHECK_EMAIL_SQL)) {
            
            ps.setString(1, email);
            
            try (ResultSet rs = ps.executeQuery()) {
                // Se c'è almeno un risultato, l'email esiste
                return rs.next();
            }
        } catch (SQLException e) {
            // In caso di errore SQL, ritorniamo true per sicurezza
            return true;
        }
    }

    /**
     * Inserisce un nuovo cliente nel database.
     * 
     * @param ragioneSociale la ragione sociale del cliente
     * @param pIva la partita IVA del cliente
     * @param email l'indirizzo email del cliente
     * @param password la password del cliente
     * @return true se l'inserimento è avvenuto con successo, false altrimenti
     */
    public boolean insert(String ragioneSociale, String pIva, String email, String password) {
    	
        // Caricamento del driver MySQL
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("MySQL driver mancante", e);
        }
        
        // Esecuzione della query di inserimento
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(INSERT_SQL)) {
            
            // Impostazione dei parametri della query
            ps.setString(1, ragioneSociale);
            ps.setString(2, pIva);
            ps.setString(3, email);
            ps.setString(4, password);
            
            // Esecuzione e verifica del risultato (deve essere 1 riga inserita)
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            // In caso di errore SQL, ritorniamo false
            return false;
        }
    }
}
