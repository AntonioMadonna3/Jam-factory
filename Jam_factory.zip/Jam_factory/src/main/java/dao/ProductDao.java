package dao;

import model.Product;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe DAO per la gestione dei prodotti nel database.
 * Gestisce le operazioni CRUD sui prodotti e il relativo stock.
 */
public class ProductDao {

    // Configurazione database
    private static final String JDBC_URL  = "jdbc:mysql://localhost:3306/jam_factory?useSSL=false&characterEncoding=UTF-8";
    private static final String DB_USER   = "root";
    private static final String DB_PASS   = "password";

    // Query per la selezione di tutti i prodotti con stock
    private static final String SELECT_ALL = 
      "SELECT p.id, p.nome, p.descrizione, p.prezzo_unit, s.qty_pezzi " +
      "FROM products p JOIN stock s ON p.id = s.product_id";

    // Query per ottenere lo stock di un prodotto specifico
    private static final String SELECT_STOCK = "SELECT qty_pezzi FROM stock WHERE product_id = ?";

    // Query per inserire un nuovo prodotto
    private static final String INSERT_PRODUCT = 
      "INSERT INTO products (nome, descrizione, prezzo_unit) VALUES (?,?,?)";

    // Query per inserire un record stock iniziale
    private static final String INSERT_STOCK = 
      "INSERT INTO stock (product_id, qty_pezzi) VALUES (?,0)";

    // Query per aggiornare un prodotto esistente
    private static final String UPDATE_PRODUCT = 
      "UPDATE products SET nome=?, descrizione=?, prezzo_unit=? WHERE id=?";

    // Query per eliminare stock e prodotto
    private static final String DELETE_STOCK  = "DELETE FROM stock WHERE product_id=?";
    private static final String DELETE_PRODUCT= "DELETE FROM products WHERE id=?";
    
    // Query per aggiungere stock
    private static final String ADD_STOCK     = "UPDATE stock SET qty_pezzi = qty_pezzi + ? WHERE product_id = ?";
    
    // Query per selezionare prodotti non presenti nella taste list
    private static final String SELECT_PRODUCTS_NOT_IN_TASTE_LIST = 
        "SELECT p.id, p.nome, p.descrizione, p.prezzo_unit, COALESCE(s.qty_pezzi, 0) as stock " +
        "FROM products p " +
        "LEFT JOIN stock s ON p.id = s.product_id " +
        "LEFT JOIN taste_list tl ON p.id = tl.product_id " +
        "WHERE tl.product_id IS NULL " +
        "ORDER BY p.nome";

    // Query per selezionare prodotti disponibili nello shop (non in taste list)
    private static final String SELECT_SHOP_PRODUCTS = 
    	    "SELECT p.id, p.nome, p.descrizione, p.prezzo_unit, COALESCE(s.qty_pezzi, 0) as stock " +
    	    "FROM products p " +
    	    "LEFT JOIN stock s ON p.id = s.product_id " +
    	    "LEFT JOIN taste_list tl ON p.id = tl.product_id " +
    	    "WHERE tl.product_id IS NULL " +
    	    "ORDER BY p.nome";

    // Query alternativa per escludere prodotti dalla taste list
    private static final String SELECT_ALL_EXCLUDE_TASTE = 
    	    "SELECT p.id, p.nome, p.descrizione, p.prezzo_unit, COALESCE(s.qty_pezzi, 0) as stock " +
    	    "FROM products p " +
    	    "LEFT JOIN stock s ON p.id = s.product_id " +
    	    "LEFT JOIN taste_list tl ON p.id = tl.product_id " +
    	    "WHERE tl.product_id IS NULL " +
    	    "ORDER BY p.nome";
    
    // Query per inserire stock se non esiste già
    private static final String INSERT_STOCK_IF_NOT_EXISTS = 
    	    "INSERT IGNORE INTO stock (product_id, qty_pezzi) VALUES (?, 0)";

    /**
     * Assicura che esista un record stock per il prodotto specificato.
     * Se non esiste, lo crea con quantità 0.
     */
    public void ensureStockExists(int productId) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(INSERT_STOCK_IF_NOT_EXISTS)) {
            ps.setInt(1, productId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Trova tutti i prodotti disponibili per lo shop.
     * Esclude i prodotti presenti nella taste list.
     */
    public List<Product> findShopProducts() {
        List<Product> products = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(SELECT_SHOP_PRODUCTS)) {

            while (rs.next()) {
                products.add(new Product(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("descrizione"),
                    rs.getBigDecimal("prezzo_unit"),
                    rs.getInt("stock")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    /**
     * Trova tutti i prodotti escludendo quelli nella taste list.
     * Utilizzato per la gestione amministrativa dei prodotti.
     */
    public List<Product> findAllExcludingTasteList() {
        List<Product> products = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(SELECT_ALL_EXCLUDE_TASTE)) {

            while (rs.next()) {
                products.add(new Product(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("descrizione"),
                    rs.getBigDecimal("prezzo_unit"),
                    rs.getInt("stock")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    /**
     * Trova prodotti che NON sono nella taste list.
     * Utilizzato per la gestione dei prodotti amministrativi.
     */
    public List<Product> findProductsNotInTasteList() {
        List<Product> products = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(SELECT_PRODUCTS_NOT_IN_TASTE_LIST)) {

            while (rs.next()) {
                products.add(new Product(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("descrizione"),
                    rs.getBigDecimal("prezzo_unit"),
                    rs.getInt("stock")
                ));
            }
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
        return products;
    }

    /**
     * Recupera tutti i prodotti con le relative informazioni di stock.
     */
    public List<Product> findAll() {
        List<Product> list = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(SELECT_ALL)) {
            while (rs.next()) {
                list.add(new Product(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("descrizione"),
                    rs.getBigDecimal("prezzo_unit"),
                    rs.getInt("qty_pezzi")
                ));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
    
    /**
     * Trova un prodotto specifico tramite il suo ID.
     * Include le informazioni di stock utilizzando LEFT JOIN.
     */
    public Product findById(int id) {
        String sql = """
            SELECT p.id, p.nome, p.descrizione, p.prezzo_unit,
                   COALESCE(s.qty_pezzi, 0) AS stock
            FROM products p
            LEFT JOIN stock s ON p.id = s.product_id
            WHERE p.id = ?
            """;

        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, id);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Product(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("descrizione"),
                        rs.getBigDecimal("prezzo_unit"),
                        rs.getInt("stock")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Ottiene la quantità attuale in stock per un prodotto specifico.
     */
    public int getCurrentStock(int productId) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(SELECT_STOCK)) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("qty_pezzi");
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    /**
     * Inserisce un nuovo prodotto nel database.
     * Crea automaticamente un record stock iniziale con quantità 0.
     * Utilizza transazioni per garantire coerenza dei dati.
     */
    public int insert(Product p) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(INSERT_PRODUCT, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, p.getNome());
                ps.setString(2, p.getDescrizione());
                ps.setBigDecimal(3, p.getPrezzo());
                if (ps.executeUpdate()!=1) { c.rollback(); return 0; }
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        int id = keys.getInt(1);
                        try (PreparedStatement ps2 = c.prepareStatement(INSERT_STOCK)) {
                            ps2.setInt(1, id);
                            ps2.executeUpdate();
                        }
                        c.commit();
                        p.setId(id);
                        return id;
                    }
                }
            }
            c.rollback();
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    /**
     * Aggiorna le informazioni di un prodotto esistente.
     * Non modifica le informazioni di stock.
     */
    public boolean update(Product p) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(UPDATE_PRODUCT)) {
            ps.setString(1, p.getNome());
            ps.setString(2, p.getDescrizione());
            ps.setBigDecimal(3, p.getPrezzo());
            ps.setInt(4, p.getId());
            return ps.executeUpdate()==1;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    /**
     * Elimina un prodotto e il relativo stock dal database.
     * Utilizza transazioni per garantire l'eliminazione completa.
     */
    public boolean delete(int id) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
            c.setAutoCommit(false);
            try (PreparedStatement ps1 = c.prepareStatement(DELETE_STOCK);
                 PreparedStatement ps2 = c.prepareStatement(DELETE_PRODUCT)) {
                ps1.setInt(1, id);
                ps1.executeUpdate();
                ps2.setInt(1, id);
                ps2.executeUpdate();
                c.commit();
                return true;
            }
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    /**
     * Aggiunge una quantità specificata allo stock di un prodotto.
     * Il delta può essere positivo (aggiunta) o negativo (sottrazione).
     */
    public boolean addStock(int productId, int delta) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(ADD_STOCK)) {
            ps.setInt(1, delta);
            ps.setInt(2, productId);
            return ps.executeUpdate()==1;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    /**
     * Rimuove una quantità specificata dallo stock di un prodotto.
     * Verifica che ci sia abbastanza stock disponibile prima della rimozione.
     */
    public boolean removeStock(int productId, int delta) {
        int currentStock = getCurrentStock(productId);
        if (currentStock < delta) {
            return false; // Non può rimuovere più di quello che ha
        }
        return addStock(productId, -delta);
    }
}
