package dao;

import model.CartItem;
import model.CustomerOrder;
import java.sql.*;
import java.math.BigDecimal;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object per la gestione degli ordini dei clienti.
 * Fornisce metodi per creare ordini, recuperare dati storici e statistiche.
 */
public class OrderDao {
    // Configurazione database
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/jam_factory?useSSL=false&characterEncoding=UTF-8";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "password";

    // Query SQL per inserimento ordini
    private static final String INSERT_ORDER = 
        "INSERT INTO customer_orders (customer_id, total_eur) VALUES (?, ?)";
    
    private static final String INSERT_ORDER_ITEM = 
        "INSERT INTO order_items (order_id, product_id, qty, price_eur) VALUES (?, ?, ?, ?)";
    
    // Query SQL per recupero dati ordini
    private static final String SELECT_CUSTOMER_ORDERS = 
        "SELECT id, total_eur, ordered_at FROM customer_orders WHERE customer_id = ? ORDER BY ordered_at DESC";
    
    private static final String SELECT_ORDER_ITEMS = 
        "SELECT oi.product_id, oi.qty, oi.price_eur, p.nome as product_name " +
        "FROM order_items oi " +
        "INNER JOIN products p ON oi.product_id = p.id " +
        "WHERE oi.order_id = ?";

    private static final String SELECT_RECENT_ORDERS = 
    	    "SELECT co.id, co.customer_id, co.total_eur, co.ordered_at, " +
    	    "c.ragione_sociale as customer_name " +
    	    "FROM customer_orders co " +
    	    "INNER JOIN customers c ON co.customer_id = c.id " +
    	    "ORDER BY co.ordered_at DESC LIMIT 10";

    /**
     * Recupera tutti gli articoli di un determinato ordine.
     * 
     * @param orderId ID dell'ordine
     * @return Lista degli articoli presenti nell'ordine
     */
    public List<CartItem> getOrderItems(int orderId) {
        List<CartItem> items = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(SELECT_ORDER_ITEMS)) {
            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    items.add(new CartItem(
                        rs.getInt("product_id"),
                        rs.getString("product_name"),
                        rs.getBigDecimal("price_eur"),
                        rs.getInt("qty"),
                        0 // stock disponibile non rilevante per articoli già ordinati
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }
    
    /**
     * Recupera gli ultimi 10 ordini effettuati, incluso il nome del cliente.
     * 
     * @return Lista degli ordini più recenti con informazioni del cliente
     */
    public List<CustomerOrder> getRecentOrders() {
        List<CustomerOrder> orders = new ArrayList<>();
        
        String query = "SELECT co.id, co.customer_id, co.total_eur, co.ordered_at, " +
                       "c.ragione_sociale as customer_name " +
                       "FROM customer_orders co " +
                       "INNER JOIN customers c ON co.customer_id = c.id " +
                       "ORDER BY co.ordered_at DESC LIMIT 10";
        
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            
            while (rs.next()) {
                CustomerOrder order = new CustomerOrder(
                    rs.getInt("id"),
                    rs.getInt("customer_id"),
                    rs.getBigDecimal("total_eur"),
                    rs.getTimestamp("ordered_at")
                );
                order.setCustomerName(rs.getString("customer_name"));
                orders.add(order);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    /**
     * Conta il numero di ordini effettuati nella giornata corrente.
     * 
     * @return Numero di ordini di oggi
     */
    public int getTodayOrdersCount() {
        String query = "SELECT COUNT(*) FROM customer_orders WHERE DATE(ordered_at) = CURDATE()";
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Calcola il totale delle vendite della giornata corrente.
     * 
     * @return Importo totale delle vendite di oggi
     */
    public BigDecimal getTodaySales() {
        String query = "SELECT COALESCE(SUM(total_eur), 0) FROM customer_orders WHERE DATE(ordered_at) = CURDATE()";
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            if (rs.next()) {
                return rs.getBigDecimal(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return BigDecimal.ZERO;
    }

    /**
     * Conta il numero totale di prodotti nel catalogo.
     * 
     * @return Numero totale di prodotti
     */
    public int getTotalProductsCount() {
        String query = "SELECT COUNT(*) FROM products";
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Conta il numero totale di clienti registrati.
     * 
     * @return Numero totale di clienti
     */
    public int getTotalCustomersCount() {
        String query = "SELECT COUNT(*) FROM customers";
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    /**
     * Crea un nuovo ordine per un cliente con i relativi articoli.
     * Utilizza una transazione per garantire la consistenza dei dati.
     * 
     * @param customerId ID del cliente che effettua l'ordine
     * @param total Totale dell'ordine in euro
     * @param cartItems Mappa degli articoli nel carrello
     * @return ID dell'ordine creato, 0 se fallisce
     */
    public int createOrder(int customerId, BigDecimal total, Map<Integer, CartItem> cartItems) {
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
            c.setAutoCommit(false); // Inizio transazione
            
            // Inserimento ordine principale
            try (PreparedStatement ps = c.prepareStatement(INSERT_ORDER, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, customerId);
                ps.setBigDecimal(2, total);
                
                if (ps.executeUpdate() == 1) {
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (keys.next()) {
                            int orderId = keys.getInt(1);
                            
                            // Inserimento articoli dell'ordine
                            try (PreparedStatement psItems = c.prepareStatement(INSERT_ORDER_ITEM)) {
                                for (CartItem item : cartItems.values()) {
                                    psItems.setInt(1, orderId);
                                    psItems.setInt(2, item.getProductId());
                                    psItems.setInt(3, item.getQuantity());
                                    psItems.setBigDecimal(4, item.getUnitPrice());
                                    psItems.executeUpdate();
                                }
                            }
                            
                            c.commit(); // Conferma transazione
                            return orderId;
                        }
                    }
                }
            }
            c.rollback(); // Annulla transazione in caso di errore
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Recupera tutti gli ordini di un determinato cliente.
     * 
     * @param customerId ID del cliente
     * @return Lista degli ordini del cliente ordinati per data decrescente
     */
    public List<CustomerOrder> getCustomerOrders(int customerId) {
        List<CustomerOrder> orders = new ArrayList<>();
        try (Connection c = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS);
             PreparedStatement ps = c.prepareStatement(SELECT_CUSTOMER_ORDERS)) {
            ps.setInt(1, customerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    orders.add(new CustomerOrder(
                        rs.getInt("id"),
                        customerId,
                        rs.getBigDecimal("total_eur"),
                        rs.getTimestamp("ordered_at")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
}
