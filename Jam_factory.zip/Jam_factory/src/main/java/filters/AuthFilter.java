package filters;

import model.User.Role;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebFilter({"/admin/*","/shop/*","/taste/*"})
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest sreq, ServletResponse sresp,
                         FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  req  = (HttpServletRequest) sreq;
        HttpServletResponse resp = (HttpServletResponse) sresp;

        /* 1. Sessione sicura: può essere null */
        HttpSession session = req.getSession(false);
        Role ruolo = session != null
                     ? (Role) session.getAttribute("ruolo")
                     : null;                                       // <-- fix NPE

        String path = req.getServletPath();        // es: /admin/dashboard

        boolean ok =
            (path.startsWith("/admin") && ruolo == Role.ADMIN)     ||
            (path.startsWith("/shop")  && ruolo == Role.CLIENT)    ||
            (path.startsWith("/taste") && ruolo == Role.EMPLOYEE);

        if (!ok) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }
        chain.doFilter(req, resp);
    }
}