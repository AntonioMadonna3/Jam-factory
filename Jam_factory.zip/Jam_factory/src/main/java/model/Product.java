package model;

import java.math.BigDecimal;

/**
 * Product.java – POJO per tabella products + stock.
 */
public class Product {

    private int id;
    private String nome;
    private String descrizione;
    private BigDecimal prezzo;
    private int stock;

    public Product(int id, String nome, String descrizione, BigDecimal prezzo, int stock) {
        this.id = id;
        this.nome = nome;
        this.descrizione = descrizione;
        this.prezzo = prezzo;
        this.stock = stock;
    }

    public Product(String nome, String descrizione, BigDecimal prezzo) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.prezzo = prezzo;
    }

    // --- Getters ---
    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getDescrizione() { return descrizione; }
    public BigDecimal getPrezzo() { return prezzo; }
    public int getStock() { return stock; }

    // --- Setters ---
    public void setId(int id) { this.id = id; }
    public void setStock(int stock) { this.stock = stock; }
}
