package model;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * RawMaterialOrder.java – POJO per tabella raw_material_orders.
 */
public class RawMaterialOrder {

    private int id;
    private int supplierId;
    private BigDecimal qtyKg;
    private Timestamp orderedAt;
    
    // Fields per join con supplier
    private String supplierName;
    private String materiaPrima;

    public RawMaterialOrder(int id, int supplierId, BigDecimal qtyKg, Timestamp orderedAt) {
        this.id = id;
        this.supplierId = supplierId;
        this.qtyKg = qtyKg;
        this.orderedAt = orderedAt;
    }

    public RawMaterialOrder(int supplierId, BigDecimal qtyKg) {
        this.supplierId = supplierId;
        this.qtyKg = qtyKg;
    }

    // --- Getters ---
    public int getId() { return id; }
    public int getSupplierId() { return supplierId; }
    public BigDecimal getQtyKg() { return qtyKg; }
    public Timestamp getOrderedAt() { return orderedAt; }
    public String getSupplierName() { return supplierName; }
    public String getMateriaPrima() { return materiaPrima; }

    // --- Setters ---
    public void setId(int id) { this.id = id; }
    public void setSupplierId(int supplierId) { this.supplierId = supplierId; }
    public void setQtyKg(BigDecimal qtyKg) { this.qtyKg = qtyKg; }
    public void setOrderedAt(Timestamp orderedAt) { this.orderedAt = orderedAt; }
    public void setSupplierName(String supplierName) { this.supplierName = supplierName; }
    public void setMateriaPrima(String materiaPrima) { this.materiaPrima = materiaPrima; }
}