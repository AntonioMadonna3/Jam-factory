package model;

import java.sql.Timestamp;

public class Feedback {
    private int employeeId;
    private int productId;
    private String productName;
    private String employeeName;
    private int rating;
    private String note;
    private Timestamp givenAt;

    public Feedback(int employeeId, int productId, int rating, String note, Timestamp givenAt) {
        this.employeeId = employeeId;
        this.productId = productId;
        this.rating = rating;
        this.note = note;
        this.givenAt = givenAt;
    }

    public Feedback(int employeeId, int productId, String productName, String employeeName, 
                   int rating, String note, Timestamp givenAt) {
        this.employeeId = employeeId;
        this.productId = productId;
        this.productName = productName;
        this.employeeName = employeeName;
        this.rating = rating;
        this.note = note;
        this.givenAt = givenAt;
    }

    // Getters
    public int getEmployeeId() { return employeeId; }
    public int getProductId() { return productId; }
    public String getProductName() { return productName; }
    public String getEmployeeName() { return employeeName; }
    public int getRating() { return rating; }
    public String getNote() { return note; }
    public Timestamp getGivenAt() { return givenAt; }

    // Setters
    public void setProductName(String productName) { this.productName = productName; }
    public void setEmployeeName(String employeeName) { this.employeeName = employeeName; }
}
