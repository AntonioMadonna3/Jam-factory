package model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

public class CustomerOrder {
    private int id;
    private int customerId;
    private BigDecimal totalEur;
    private Timestamp orderedAt;
 // Add these fields and methods to CustomerOrder.java

    private String customerName;
    private List<CartItem> items;

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public List<CartItem> getItems() { return items; }
    public void setItems(List<CartItem> items) { this.items = items; }


    public CustomerOrder(int id, int customerId, BigDecimal totalEur, Timestamp orderedAt) {
        this.id = id;
        this.customerId = customerId;
        this.totalEur = totalEur;
        this.orderedAt = orderedAt;
    }

    // Getters
    public int getId() { return id; }
    public int getCustomerId() { return customerId; }
    public BigDecimal getTotalEur() { return totalEur; }
    public Timestamp getOrderedAt() { return orderedAt; }
}
