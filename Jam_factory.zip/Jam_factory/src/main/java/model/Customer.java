package model;

/**
 * Customer.java – POJO per la tabella customers
 */
public class Customer {
    private int id;
    private String ragioneSociale;
    private String pIva;
    private String email;
    private String password;

    public Customer(String ragioneSociale, String pIva, String email, String password) {
        this.ragioneSociale = ragioneSociale;
        this.pIva = pIva;
        this.email = email;
        this.password = password;
    }

    public Customer(int id, String ragioneSociale, String pIva, String email) {
        this.id = id;
        this.ragioneSociale = ragioneSociale;
        this.pIva = pIva;
        this.email = email;
    }

    // --- Getters ---
    public int getId() { return id; }
    public String getRagioneSociale() { return ragioneSociale; }
    public String getPIva() { return pIva; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }

    // --- Setters opzionali ---
    public void setId(int id) { this.id = id; }
}
