package model;

/**
 * Supplier.java – POJO per tabella suppliers.
 */
public class Supplier {

    private int id;
    private String ragioneSociale;
    private String pIva;
    private String materiaPrima;

    public Supplier(int id, String ragioneSociale, String pIva, String materiaPrima) {
        this.id = id;
        this.ragioneSociale = ragioneSociale;
        this.pIva = pIva;
        this.materiaPrima = materiaPrima;
    }

    public Supplier(String ragioneSociale, String pIva, String materiaPrima) {
        this.ragioneSociale = ragioneSociale;
        this.pIva = pIva;
        this.materiaPrima = materiaPrima;
    }

    // --- Getters ---
    public int getId() { return id; }
    public String getRagioneSociale() { return ragioneSociale; }
    public String getPIva() { return pIva; }
    public String getMateriaPrima() { return materiaPrima; }

    // --- Setters ---
    public void setId(int id) { this.id = id; }
    public void setRagioneSociale(String ragioneSociale) { this.ragioneSociale = ragioneSociale; }
    public void setPIva(String pIva) { this.pIva = pIva; }
    public void setMateriaPrima(String materiaPrima) { this.materiaPrima = materiaPrima; }
}