package controllers;

import dao.FeedbackDao;
import model.Feedback;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Servlet che gestisce la visualizzazione e l'analisi dei feedback dell'amministratore.
 * Fornisce una panoramica completa di tutti i feedback ricevuti con statistiche dettagliate.
 * 
 * Mappato sul percorso: /admin/feedback
 */
@WebServlet("/admin/feedback")
public class AdminFeedbackServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private transient FeedbackDao feedbackDao;

    /**
     * Inizializza il servlet creando l'istanza del DAO per i feedback.
     */
    @Override
    public void init() {
        feedbackDao = new FeedbackDao();
    }

    /**
     * Gestisce le richieste GET per visualizzare la pagina dei feedback amministratore.
     * Carica tutti i feedback, calcola statistiche aggregate e li organizza per prodotto.
     * 
     * @param req la richiesta HTTP
     * @param resp la risposta HTTP
     * @throws ServletException se si verifica un errore del servlet
     * @throws IOException se si verifica un errore di I/O
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Verifica autenticazione amministratore
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("adminId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Carica tutti i feedback dal database
        List<Feedback> feedbacks = feedbackDao.getAllFeedback();
        req.setAttribute("feedbacks", feedbacks);

        // Calcola statistiche aggregate sui feedback
        
        // Numero totale di feedback ricevuti
        req.setAttribute("totalFeedbacks", feedbacks.size());
        
        // Numero di dipendenti unici che hanno lasciato feedback
        long uniqueEmployees = feedbacks.stream()
            .map(Feedback::getEmployeeId)
            .distinct()
            .count();
        req.setAttribute("uniqueEmployees", uniqueEmployees);
        
        // Numero di prodotti unici che hanno ricevuto feedback
        long uniqueProducts = feedbacks.stream()
            .map(Feedback::getProductId)
            .distinct()
            .count();
        req.setAttribute("uniqueProducts", uniqueProducts);
        
        // Calcola la valutazione media di tutti i feedback
        double averageRating = feedbacks.stream()
            .mapToInt(Feedback::getRating)
            .average()
            .orElse(0.0);
        req.setAttribute("averageRating", averageRating);

        // Raggruppa i feedback per nome prodotto per facilitare l'analisi
        Map<String, List<Feedback>> feedbacksByProduct = feedbacks.stream()
            .collect(Collectors.groupingBy(Feedback::getProductName));
        req.setAttribute("feedbacksByProduct", feedbacksByProduct);

        // Inoltra alla pagina JSP dei feedback amministratore
        req.getRequestDispatcher("/WEB-INF/views/admin/feedback.jsp")
           .forward(req, resp);
    }
}