package controllers;

import dao.ProductDao;
import model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Comparator;
import java.util.stream.Collectors;

/**
 * Servlet che gestisce la pagina principale del negozio online.
 * Visualizza i prodotti disponibili con funzionalità di ricerca e ordinamento.
 * Richiede autenticazione dell'utente tramite sessione.
 */
@WebServlet("/shop")
public class ShopHomeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // DAO per l'accesso ai dati dei prodotti
    private transient ProductDao productDao;

    /**
     * Inizializza il servlet creando un'istanza del ProductDao.
     * Viene chiamato automaticamente dal container servlet.
     */
    @Override
    public void init() {
        productDao = new ProductDao();
    }

    /**
     * Gestisce le richieste GET per visualizzare la pagina del negozio.
     * Implementa le seguenti funzionalità:
     * - Verifica dell'autenticazione utente
     * - Caricamento di tutti i prodotti dal database
     * - Filtro di ricerca per nome prodotto
     * - Ordinamento per nome, prezzo o stock
     * 
     * @param req richiesta HTTP contenente parametri di ricerca e ordinamento
     * @param resp risposta HTTP per reindirizzamento o errori
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Verifica autenticazione: controlla se esiste una sessione valida con customerId
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("customerId") == null) {
            // Utente non autenticato: reindirizza alla pagina di login
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        try {
            // Estrazione parametri di ricerca e ordinamento dalla query string
            String searchQuery = req.getParameter("search");
            String sortBy = req.getParameter("sortBy");

            // Caricamento di tutti i prodotti disponibili nel negozio
            List<Product> products = productDao.findShopProducts();

            // Applicazione del filtro di ricerca se presente
            // Ricerca case-insensitive sul nome del prodotto
            if (searchQuery != null && !searchQuery.trim().isEmpty()) {
                products = products.stream()
                    .filter(p -> p.getNome().toLowerCase().contains(searchQuery.toLowerCase().trim()))
                    .collect(Collectors.toList());
            }

            // Applicazione dell'ordinamento in base al parametro sortBy
            if (sortBy != null && !sortBy.isEmpty()) {
                switch (sortBy) {
                    case "nome":
                        // Ordinamento alfabetico crescente per nome
                        products.sort(Comparator.comparing(Product::getNome));
                        break;
                    case "nome_desc":
                        // Ordinamento alfabetico decrescente per nome
                        products.sort(Comparator.comparing(Product::getNome).reversed());
                        break;
                    case "prezzo":
                        // Ordinamento crescente per prezzo
                        products.sort(Comparator.comparing(Product::getPrezzo));
                        break;
                    case "prezzo_desc":
                        // Ordinamento decrescente per prezzo
                        products.sort(Comparator.comparing(Product::getPrezzo).reversed());
                        break;
                    case "stock":
                        // Ordinamento decrescente per quantità in magazzino
                        products.sort(Comparator.comparing(Product::getStock).reversed());
                        break;
                    default:
                        // Ordinamento predefinito per nome in caso di valore non riconosciuto
                        products.sort(Comparator.comparing(Product::getNome));
                        break;
                }
            } else {
                // Ordinamento predefinito per nome se non specificato alcun criterio
                products.sort(Comparator.comparing(Product::getNome));
            }

            // Passaggio della lista prodotti alla JSP e forward alla vista
            req.setAttribute("products", products);
            req.getRequestDispatcher("/WEB-INF/views/shop/home.jsp")
               .forward(req, resp);
               
        } catch (Exception e) {
            // Gestione errori: log dell'eccezione e invio di errore 500 al client
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Errore durante il caricamento dei prodotti");
        }
    }
}

