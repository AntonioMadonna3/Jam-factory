package controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.regex.Pattern;
import dao.CustomerDao;

/**
 * Servlet per la gestione della registrazione dei clienti
 * Mappa l'URL "/client/register" e gestisce sia la visualizzazione
 * del form di registrazione che l'elaborazione dei dati inviati
 */
@WebServlet("/client/register")
public class RegisterClientServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	// DAO per l'accesso ai dati dei clienti (transient per evitare problemi di serializzazione)
	private transient CustomerDao customerDao;

    /**
     * Inizializzazione del servlet: crea l'istanza del DAO
     */
    @Override
    public void init() {
        customerDao = new CustomerDao();
    }

    /**
     * Gestisce le richieste GET: mostra il form di registrazione
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Forward alla pagina JSP del form di registrazione
        req.getRequestDispatcher("/WEB-INF/views/client/register.jsp")
           .forward(req, resp);
    }

    /**
     * Gestisce le richieste POST: elabora i dati del form di registrazione
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Estrazione dei parametri dal form
        String ragioneSociale = req.getParameter("ragione_sociale");
        String pIva           = req.getParameter("p_iva");
        String email          = req.getParameter("email");
        String pwd            = req.getParameter("password");
        String pwd2           = req.getParameter("password2");

        // Validazione lato server dei dati inseriti
        // - Ragione sociale non vuota
        // - Partita IVA di esattamente 11 cifre
        // - Email contenente il simbolo @
        // - Password di almeno 4 caratteri e conferma password corrispondente
        if (ragioneSociale == null || ragioneSociale.isBlank() ||
            pIva == null || !Pattern.matches("\\d{11}", pIva) ||
            email == null || !email.contains("@") ||
            pwd == null || pwd.length() < 4 || !pwd.equals(pwd2)) {

            // Se la validazione fallisce, mostra errore e ritorna al form
            req.setAttribute("errorMsg", "Dati non validi o password non coincidenti");
            doGet(req, resp);
            return;
        }

        // Verifica se l'email è già registrata nel sistema
        if (customerDao.emailExists(email)) {
            req.setAttribute("errorMsg", "Indirizzo email già registrato");
            doGet(req, resp);
            return;
        }

        // Tentativo di inserimento del nuovo cliente nel database
        boolean ok = customerDao.insert(ragioneSociale, pIva, email, pwd);
        if (!ok) {
            // Se l'inserimento fallisce, mostra errore generico
            req.setAttribute("errorMsg", "Errore interno, riprova più tardi");
            doGet(req, resp);
            return;
        }

        // Registrazione completata con successo: redirect alla pagina di login
        // con parametro per indicare l'avvenuta registrazione
        resp.sendRedirect(req.getContextPath() + "/login?registered=1");
    }
}
