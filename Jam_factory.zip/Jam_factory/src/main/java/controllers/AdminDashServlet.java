package controllers;

import dao.OrderDao;
import model.CustomerOrder;
import model.CartItem;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

/**
 * Servlet che gestisce la dashboard dell'amministratore.
 * Fornisce una panoramica delle statistiche del negozio e degli ordini recenti.
 * 
 * Mappato sui percorsi:
 * - /admin
 * - /admin/dashboard
 */
@WebServlet({"/admin", "/admin/dashboard"})
public class AdminDashServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private transient OrderDao orderDao;

    /**
     * Inizializza il servlet creando l'istanza del DAO per gli ordini.
     */
    @Override
    public void init() {
        orderDao = new OrderDao();
    }

    /**
     * Gestisce le richieste GET alla dashboard dell'amministratore.
     * Carica le statistiche del negozio e gli ordini recenti per visualizzarli nella dashboard.
     * 
     * @param req la richiesta HTTP
     * @param resp la risposta HTTP
     * @throws ServletException se si verifica un errore del servlet
     * @throws IOException se si verifica un errore di I/O
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        try {
            // Carica gli ordini recenti con i relativi articoli
            List<CustomerOrder> recentOrders = orderDao.getRecentOrders();
            
            // Per ogni ordine, carica gli articoli associati
            for (CustomerOrder order : recentOrders) {
                List<CartItem> items = orderDao.getOrderItems(order.getId());
                order.setItems(items);
            }

            // Carica le statistiche del negozio
            int todayOrders = orderDao.getTodayOrdersCount();        // Numero ordini di oggi
            BigDecimal todaySales = orderDao.getTodaySales();        // Vendite di oggi
            int totalProducts = orderDao.getTotalProductsCount();    // Totale prodotti in catalogo
            int totalCustomers = orderDao.getTotalCustomersCount();  // Totale clienti registrati

            // Imposta gli attributi per la JSP
            req.setAttribute("recentOrders", recentOrders);
            req.setAttribute("todayOrders", todayOrders);
            req.setAttribute("todaySales", todaySales);
            req.setAttribute("totalProducts", totalProducts);
            req.setAttribute("totalCustomers", totalCustomers);
            
            // Inoltra alla pagina JSP della dashboard
            req.getRequestDispatcher("/WEB-INF/views/admin/dashboard.jsp").forward(req, resp);
            
        } catch (Exception e) {
            // In caso di errore, rilancia l'eccezione per permettere la gestione degli errori a livello superiore
            throw new ServletException("Errore durante il caricamento della dashboard amministratore", e);
        }
    }
}