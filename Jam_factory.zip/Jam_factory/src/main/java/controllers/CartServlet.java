package controllers;

import dao.ProductDao;
import model.Product;
import model.CartItem;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Servlet per la gestione del carrello della spesa.
 * Gestisce le operazioni di aggiunta, modifica e rimozione prodotti dal carrello.
 * Mappato su "/shop/cart/*" per gestire tutte le azioni relative al carrello.
 */
@WebServlet("/shop/cart/*")
public class CartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private transient ProductDao productDao;

    /**
     * Inizializza il servlet creando un'istanza del DAO per i prodotti.
     */
    @Override
    public void init() {
        productDao = new ProductDao();
    }

    /**
     * Gestisce le richieste GET per visualizzare il carrello.
     * Verifica l'autenticazione del cliente prima di mostrare la pagina.
     * 
     * @param req richiesta HTTP
     * @param resp risposta HTTP
     * @throws ServletException se si verifica un errore nel servlet
     * @throws IOException se si verifica un errore di I/O
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Verifica se il cliente è autenticato
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("customerId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Inoltra alla pagina del carrello
        req.getRequestDispatcher("/WEB-INF/views/shop/cart.jsp")
           .forward(req, resp);
    }

    /**
     * Gestisce le richieste POST per le operazioni sul carrello (add, update, remove).
     * Verifica l'autenticazione e instrada l'azione appropriata.
     * 
     * @param req richiesta HTTP
     * @param resp risposta HTTP
     * @throws ServletException se si verifica un errore nel servlet
     * @throws IOException se si verifica un errore di I/O
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Verifica autenticazione del cliente
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("customerId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Estrae l'azione dal path della richiesta
        String action = req.getPathInfo();
        if (action == null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }

        // Instrada l'azione appropriata
        switch (action) {
            case "/add" -> doAddToCart(req, resp);
            case "/update" -> doUpdateCart(req, resp);
            case "/remove" -> doRemoveFromCart(req, resp);
            default -> resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    /**
     * Aggiunge un prodotto al carrello o aumenta la quantità se già presente.
     * Verifica la disponibilità dello stock prima di aggiungere.
     */
    @SuppressWarnings("unchecked")
    private void doAddToCart(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession();
        
        // Estrae i parametri dalla richiesta
        int productId = Integer.parseInt(req.getParameter("productId"));
        int quantity = Integer.parseInt(req.getParameter("quantity"));
        
        // Verifica l'esistenza del prodotto
        Product product = productDao.findById(productId);
        if (product == null) {
            session.setAttribute("errorMessage", "Prodotto non trovato!");
            resp.sendRedirect(req.getContextPath() + "/shop");
            return;
        }

        // Verifica la disponibilità dello stock
        if (product.getStock() < quantity) {
            session.setAttribute("errorMessage", "Quantità richiesta non disponibile in stock!");
            resp.sendRedirect(req.getContextPath() + "/shop");
            return;
        }

        // Recupera o crea il carrello dalla sessione
        Map<Integer, CartItem> cart = (Map<Integer, CartItem>) session.getAttribute("cart");
        if (cart == null) {
            cart = new HashMap<>();
            session.setAttribute("cart", cart);
        }

        // Gestisce l'aggiunta del prodotto al carrello
        CartItem existingItem = cart.get(productId);
        if (existingItem != null) {
            // Prodotto già presente: aumenta la quantità
            int newQuantity = existingItem.getQuantity() + quantity;
            if (newQuantity > product.getStock()) {
                session.setAttribute("errorMessage", "Quantità totale supera lo stock disponibile!");
                resp.sendRedirect(req.getContextPath() + "/shop");
                return;
            }
            existingItem.setQuantity(newQuantity);
        } else {
            // Nuovo prodotto: crea un nuovo item nel carrello
            cart.put(productId, new CartItem(
                product.getId(),
                product.getNome(),
                product.getPrezzo(),
                quantity,
                product.getStock()
            ));
        }

        session.setAttribute("successMessage", "Prodotto aggiunto al carrello!");
        resp.sendRedirect(req.getContextPath() + "/shop");
    }

    /**
     * Aggiorna la quantità di un prodotto già presente nel carrello.
     * Verifica che la nuova quantità non superi lo stock disponibile.
     */
    @SuppressWarnings("unchecked")
    private void doUpdateCart(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession();
        
        // Estrae i parametri dalla richiesta
        int productId = Integer.parseInt(req.getParameter("productId"));
        int quantity = Integer.parseInt(req.getParameter("quantity"));
        
        // Recupera il carrello dalla sessione
        Map<Integer, CartItem> cart = (Map<Integer, CartItem>) session.getAttribute("cart");
        if (cart != null && cart.containsKey(productId)) {
            CartItem item = cart.get(productId);
            // Verifica che la quantità non superi lo stock disponibile
            if (quantity > item.getAvailableStock()) {
                session.setAttribute("errorMessage", "Quantità supera lo stock disponibile!");
            } else {
                // Aggiorna la quantità del prodotto
                item.setQuantity(quantity);
                session.setAttribute("successMessage", "Carrello aggiornato!");
            }
        }

        resp.sendRedirect(req.getContextPath() + "/shop/cart");
    }

    /**
     * Rimuove completamente un prodotto dal carrello.
     */
    @SuppressWarnings("unchecked")
    private void doRemoveFromCart(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession();
        
        // Estrae l'ID del prodotto da rimuovere
        int productId = Integer.parseInt(req.getParameter("productId"));
        
        // Recupera il carrello e rimuove il prodotto
        Map<Integer, CartItem> cart = (Map<Integer, CartItem>) session.getAttribute("cart");
        if (cart != null) {
            cart.remove(productId);
            session.setAttribute("successMessage", "Prodotto rimosso dal carrello!");
        }

        resp.sendRedirect(req.getContextPath() + "/shop/cart");
    }
}
