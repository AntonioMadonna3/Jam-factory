package controllers;

import dao.OrderDao;
import model.CustomerOrder;
import model.CartItem;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Servlet che gestisce la visualizzazione degli ordini di un cliente.
 * Mappata sul percorso "/shop/orders".
 */
@WebServlet("/shop/orders")
public class CustomerOrdersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private transient OrderDao orderDao;

    /**
     * Inizializza il DAO per la gestione degli ordini.
     */
    @Override
    public void init() {
        orderDao = new OrderDao();
    }

    /**
     * Gestisce le richieste GET per visualizzare gli ordini del cliente.
     * Verifica l'autenticazione e recupera tutti gli ordini con i relativi articoli.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Ottiene la sessione corrente senza crearne una nuova
        HttpSession session = req.getSession(false);
        
        // Verifica se l'utente è autenticato
        if (session == null || session.getAttribute("customerId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Recupera l'ID del cliente dalla sessione
        Integer customerId = (Integer) session.getAttribute("customerId");
        
        // Recupera tutti gli ordini del cliente dal database
        List<CustomerOrder> orders = orderDao.getCustomerOrders(customerId);
        
        // Per ogni ordine, recupera e associa gli articoli ordinati
        for (CustomerOrder order : orders) {
            List<CartItem> items = orderDao.getOrderItems(order.getId());
            order.setItems(items);
        }

        // Passa la lista degli ordini alla JSP e inoltra la richiesta
        req.setAttribute("orders", orders);
        req.getRequestDispatcher("/WEB-INF/views/shop/orders.jsp").forward(req, resp);
    }
}

