package controllers;

import dao.EmployeeDao;
import model.Employee;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet per la gestione della registrazione dei dipendenti.
 * Gestisce sia la visualizzazione del form di registrazione (GET)
 * che l'elaborazione dei dati inviati (POST).
 */
@WebServlet("/employee/register")
public class EmployeeRegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private transient EmployeeDao employeeDao;

    /**
     * Inizializza il DAO per l'accesso ai dati dei dipendenti.
     */
    @Override
    public void init() {
        employeeDao = new EmployeeDao();
    }

    /**
     * Gestisce le richieste GET mostrando il form di registrazione.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/employee/register.jsp")
           .forward(req, resp);
    }

    /**
     * Gestisce le richieste POST per elaborare la registrazione del dipendente.
     * Valida i dati inseriti, controlla la duplicazione dell'email e
     * inserisce il nuovo dipendente nel database.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Recupero dei parametri dal form di registrazione
        String nome    = req.getParameter("nome");
        String cognome = req.getParameter("cognome");
        String email   = req.getParameter("email");
        String pwd     = req.getParameter("password");
        String pwd2    = req.getParameter("password2");

        // Validazione dei dati inseriti
        // Controlla che i campi obbligatori non siano vuoti,
        // che l'email contenga @, che la password sia lunga almeno 4 caratteri
        // e che le due password coincidano
        boolean invalid = nome == null || nome.isBlank() ||
                          cognome == null || cognome.isBlank() ||
                          email == null || !email.contains("@") ||
                          pwd == null || pwd.length() < 4 || !pwd.equals(pwd2);
        if (invalid) {
            req.setAttribute("errorMsg", "Dati non validi o password non coincidenti");
            doGet(req, resp);
            return;
        }

        // Verifica che l'email non sia già registrata nel sistema
        if (employeeDao.emailExists(email)) {
            req.setAttribute("errorMsg", "Indirizzo email già registrato");
            doGet(req, resp);
            return;
        }

        // Creazione del nuovo oggetto Employee e inserimento nel database
        Employee emp = new Employee(nome, cognome, email, pwd);
        int id = employeeDao.insert(emp);   // restituisce PK generato
        if (id == 0) {
            req.setAttribute("errorMsg", "Errore interno, riprova più tardi");
            doGet(req, resp);
            return;
        }

        // Registrazione completata con successo: redirect alla pagina di login
        // con parametro per mostrare messaggio di conferma
        resp.sendRedirect(req.getContextPath() + "/login?registered=1");
    }
}

