package controllers;

import dao.ProductDao;
import model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

/**
 * Servlet per la gestione dei prodotti nell'area amministrativa.
 * Gestisce tutte le operazioni CRUD sui prodotti: visualizzazione, aggiunta, 
 * modifica, eliminazione e gestione dello stock.
 */
@WebServlet("/admin/products/*")
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private transient ProductDao productDao;

    /**
     * Inizializza il DAO per l'accesso ai dati dei prodotti.
     */
    @Override
    public void init() { productDao = new ProductDao(); }

    /**
     * Gestisce le richieste GET per visualizzare la lista dei prodotti.
     * Verifica l'autenticazione dell'amministratore e recupera tutti i prodotti
     * escludendo quelli della lista degustazione.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Controllo autenticazione amministratore
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("adminId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Recupera tutti i prodotti escludendo quelli della lista degustazione
        List<Product> prodotti = productDao.findAllExcludingTasteList();
        req.setAttribute("prodotti", prodotti);

        // Forward alla pagina JSP per la visualizzazione
        req.getRequestDispatcher("/WEB-INF/views/admin/products.jsp")
           .forward(req, resp);
    }

    /**
     * Gestisce le richieste POST per le operazioni sui prodotti.
     * Smista le richieste in base al path: add, update, delete, stock-add, stock-remove.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String action = req.getPathInfo(); // Estrae l'azione dal path
        if (action == null) { resp.sendError(HttpServletResponse.SC_BAD_REQUEST); return; }

        // Switch per gestire le diverse operazioni
        switch (action) {
            case "/add"       -> doAdd(req);
            case "/update"    -> doUpdate(req);
            case "/delete"    -> doDelete(req);
            case "/stock-add" -> doAddStock(req);
            case "/stock-remove" -> doRemoveStock(req, resp);
            default           -> resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
        // Redirect alla pagina dei prodotti dopo l'operazione
        resp.sendRedirect(req.getContextPath() + "/admin/products");
    }

    /**
     * Aggiunge un nuovo prodotto al database.
     * Estrae i parametri dalla richiesta e crea un nuovo oggetto Product.
     */
    private void doAdd(HttpServletRequest req) {
        String nome  = req.getParameter("nome");
        String descr = req.getParameter("descrizione");
        BigDecimal prezzo = new BigDecimal(req.getParameter("prezzo"));
        productDao.insert(new Product(nome, descr, prezzo));
    }

    /**
     * Aggiorna un prodotto esistente nel database.
     * In caso di errore, imposta un messaggio di errore nella sessione.
     */
    private void doUpdate(HttpServletRequest req) {
        int id = Integer.parseInt(req.getParameter("id"));
        String nome  = req.getParameter("nome");
        String descr = req.getParameter("descrizione");
        BigDecimal prezzo = new BigDecimal(req.getParameter("prezzo"));
        
        boolean success = productDao.update(new Product(id, nome, descr, prezzo, 0));
        if (!success) {
            HttpSession session = req.getSession();
            session.setAttribute("errorMessage", "Errore durante l'aggiornamento del prodotto!");
        }
    }

    /**
     * Elimina un prodotto dal database utilizzando l'ID.
     */
    private void doDelete(HttpServletRequest req) {
        int id = Integer.parseInt(req.getParameter("id"));
        productDao.delete(id);
    }

    /**
     * Aggiunge una quantità di stock a un prodotto esistente.
     */
    private void doAddStock(HttpServletRequest req) {
        int id = Integer.parseInt(req.getParameter("id"));
        int delta = Integer.parseInt(req.getParameter("delta"));
        productDao.addStock(id, delta);
    }
    
    /**
     * Rimuove una quantità di stock da un prodotto esistente.
     * Verifica che la quantità da rimuovere non superi lo stock disponibile.
     * In caso di errore, imposta un messaggio di errore nella sessione.
     */
    private void doRemoveStock(HttpServletRequest req, HttpServletResponse resp) {
        int id = Integer.parseInt(req.getParameter("id"));
        int delta = Integer.parseInt(req.getParameter("delta"));
        
        boolean success = productDao.removeStock(id, delta);
        if (!success) {
            HttpSession session = req.getSession();
            session.setAttribute("errorMessage", "Impossibile rimuovere più pezzi di quelli disponibili in stock!");
        }
    }
}
