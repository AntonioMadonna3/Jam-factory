package controllers;

import dao.SupplierDao;
import dao.RawMaterialOrderDao;
import model.Supplier;
import model.RawMaterialOrder;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

/**
 * Servlet per la gestione dei fornitori e degli ordini di materie prime
 * Gestisce le operazioni CRUD per fornitori e ordini nell'area amministrativa
 */
@WebServlet("/admin/suppliers/*")
public class SupplierServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    // DAO per l'accesso ai dati dei fornitori
    private transient SupplierDao supplierDao;
    // DAO per l'accesso ai dati degli ordini di materie prime
    private transient RawMaterialOrderDao orderDao;

    /**
     * Inizializza i DAO al caricamento della servlet
     */
    @Override
    public void init() { 
        supplierDao = new SupplierDao(); 
        orderDao = new RawMaterialOrderDao();
    }

    /**
     * Gestisce le richieste GET per visualizzare la pagina dei fornitori
     * Carica tutti i fornitori e gli ordini e li inoltra alla JSP
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Recupera tutti i fornitori dal database
        List<Supplier> fornitori = supplierDao.findAll();
        // Recupera tutti gli ordini di materie prime dal database
        List<RawMaterialOrder> ordini = orderDao.findAll();
        
        // Imposta gli attributi della richiesta per renderli disponibili nella JSP
        req.setAttribute("fornitori", fornitori);
        req.setAttribute("ordini", ordini);
        // Inoltra la richiesta alla pagina JSP dei fornitori
        req.getRequestDispatcher("/WEB-INF/views/admin/suppliers.jsp")
           .forward(req, resp);
    }

    /**
     * Gestisce le richieste POST per le operazioni sui fornitori e ordini
     * Identifica l'azione tramite pathInfo e la delega al metodo appropriato
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Estrae l'azione dal path della richiesta
        String action = req.getPathInfo();
        if (action == null) { resp.sendError(HttpServletResponse.SC_BAD_REQUEST); return; }

        // Switch per gestire le diverse azioni possibili
        switch (action) {
            case "/add"          -> doAdd(req);          // Aggiunge nuovo fornitore
            case "/update"       -> doUpdate(req);       // Aggiorna fornitore esistente
            case "/delete"       -> doDelete(req);       // Elimina fornitore
            case "/order/add"    -> doAddOrder(req);     // Aggiunge nuovo ordine
            case "/order/delete" -> doDeleteOrder(req);  // Elimina ordine
            default              -> resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
        // Reindirizza alla pagina dei fornitori dopo l'operazione
        resp.sendRedirect(req.getContextPath() + "/admin/suppliers");
    }

    /**
     * Aggiunge un nuovo fornitore al database
     * In caso di errore imposta un messaggio di errore nella sessione
     */
    private void doAdd(HttpServletRequest req) {
        // Estrae i parametri dal form per il nuovo fornitore
        String ragioneSociale = req.getParameter("ragione_sociale");
        String pIva = req.getParameter("p_iva");
        String materiaPrima = req.getParameter("materia_prima");

        // Tenta l'inserimento del nuovo fornitore
        int result = supplierDao.insert(new Supplier(ragioneSociale, pIva, materiaPrima));
        if (result == 0) {
            // Se l'inserimento fallisce, imposta un messaggio di errore
            HttpSession session = req.getSession();
            session.setAttribute("errorMessage", "Errore durante l'inserimento del fornitore!");
        }
    }

    /**
     * Aggiorna un fornitore esistente nel database
     * In caso di errore imposta un messaggio di errore nella sessione
     */
    private void doUpdate(HttpServletRequest req) {
        // Estrae i parametri dal form per l'aggiornamento
        int id = Integer.parseInt(req.getParameter("id"));
        String ragioneSociale = req.getParameter("ragione_sociale");
        String pIva = req.getParameter("p_iva");
        String materiaPrima = req.getParameter("materia_prima");

        // Tenta l'aggiornamento del fornitore
        boolean success = supplierDao.update(new Supplier(id, ragioneSociale, pIva, materiaPrima));
        if (!success) {
            // Se l'aggiornamento fallisce, imposta un messaggio di errore
            HttpSession session = req.getSession();
            session.setAttribute("errorMessage", "Errore durante l'aggiornamento del fornitore!");
        }
    }

    /**
     * Elimina un fornitore dal database
     * In caso di errore imposta un messaggio di errore nella sessione
     */
    private void doDelete(HttpServletRequest req) {
        // Estrae l'ID del fornitore da eliminare
        int id = Integer.parseInt(req.getParameter("id"));
        // Tenta l'eliminazione del fornitore
        boolean success = supplierDao.delete(id);
        if (!success) {
            // Se l'eliminazione fallisce, imposta un messaggio di errore
            HttpSession session = req.getSession();
            session.setAttribute("errorMessage", "Errore durante l'eliminazione del fornitore!");
        }
    }

    /**
     * Aggiunge un nuovo ordine di materie prime al database
     * In caso di errore imposta un messaggio di errore nella sessione
     */
    private void doAddOrder(HttpServletRequest req) {
        // Estrae i parametri dal form per il nuovo ordine
        int supplierId = Integer.parseInt(req.getParameter("supplier_id"));
        BigDecimal qtyKg = new BigDecimal(req.getParameter("qty_kg"));

        // Tenta l'inserimento del nuovo ordine
        int result = orderDao.insert(new RawMaterialOrder(supplierId, qtyKg));
        if (result == 0) {
            // Se l'inserimento fallisce, imposta un messaggio di errore
            HttpSession session = req.getSession();
            session.setAttribute("errorMessage", "Errore durante l'inserimento dell'ordine!");
        }
    }

    /**
     * Elimina un ordine di materie prime dal database
     * In caso di errore imposta un messaggio di errore nella sessione
     */
    private void doDeleteOrder(HttpServletRequest req) {
        // Estrae l'ID dell'ordine da eliminare
        int id = Integer.parseInt(req.getParameter("id"));
        // Tenta l'eliminazione dell'ordine
        boolean success = orderDao.delete(id);
        if (!success) {
            // Se l'eliminazione fallisce, imposta un messaggio di errore
            HttpSession session = req.getSession();
            session.setAttribute("errorMessage", "Errore durante l'eliminazione dell'ordine!");
        }
    }
}
