package controllers;

import dao.UserDao;
import model.User;
import model.User.Role;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet per la gestione del login degli utenti.
 * Gestisce sia la visualizzazione della pagina di login che l'autenticazione.
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private transient UserDao userDao;

    /**
     * Inizializza il DAO per l'accesso ai dati degli utenti.
     */
    @Override
    public void init() throws ServletException {
        userDao = new UserDao();
    }

    /**
     * Gestisce le richieste GET per visualizzare la pagina di login.
     * Se l'utente è già autenticato, lo reindirizza alla pagina appropriata.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Controlla se esiste già una sessione attiva con un ruolo
        if (req.getSession(false) != null &&
            req.getSession(false).getAttribute("ruolo") != null) {

            Role r = (Role) req.getSession(false).getAttribute("ruolo");
            // Reindirizza l'utente in base al suo ruolo
            redirectByRole(r, req, resp);
            return;
        }

        // Se non è autenticato, mostra la pagina di login
        req.getRequestDispatcher("/WEB-INF/views/login.jsp")
           .forward(req, resp);
    }

    /**
     * Gestisce le richieste POST per l'autenticazione dell'utente.
     * Valida le credenziali e crea la sessione se l'autenticazione ha successo.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Recupera i parametri email e password dal form
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        // Autentica l'utente tramite il DAO
        User user = userDao.authenticate(email, password);

        // Se l'autenticazione fallisce, mostra un messaggio di errore
        if (user == null) {
            req.setAttribute("errorMsg", "Credenziali non valide");
            req.getRequestDispatcher("/WEB-INF/views/login.jsp")
               .forward(req, resp);
            return;
        }

        // Imposta gli attributi di sessione comuni a tutti i ruoli
        req.getSession(true).setAttribute("ruolo", user.getRole());
        req.getSession().setAttribute("nome", user.getFirstName());
        
        // Imposta attributi specifici per ogni tipo di utente
        switch (user.getRole()) {
            case CLIENT -> {
                req.getSession().setAttribute("customerId", user.getId());
                req.getSession().setAttribute("userType", "customer");
            }
            case ADMIN -> {
                req.getSession().setAttribute("adminId", user.getId());
                req.getSession().setAttribute("userType", "admin");
            }
            case EMPLOYEE -> {
                req.getSession().setAttribute("employeeId", user.getId());
                req.getSession().setAttribute("userType", "employee");
            }
        }

        // Reindirizza l'utente alla pagina appropriata in base al ruolo
        redirectByRole(user.getRole(), req, resp);
    }

    /**
     * Reindirizza l'utente alla pagina appropriata in base al suo ruolo.
     * 
     * @param role Il ruolo dell'utente
     * @param req La richiesta HTTP
     * @param resp La risposta HTTP
     */
    private void redirectByRole(Role role, HttpServletRequest req,
                                HttpServletResponse resp) throws IOException {

        String ctx = req.getContextPath();

        // Reindirizza in base al ruolo dell'utente
        switch (role) {
            case ADMIN -> resp.sendRedirect(ctx + "/admin/dashboard");
            case CLIENT -> resp.sendRedirect(ctx + "/shop");
            case EMPLOYEE -> resp.sendRedirect(ctx + "/taste");
        }
    }
}

