package controllers;

import dao.ProductDao;
import dao.OrderDao;
import model.CartItem;
import model.CustomerOrder;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Map;

/**
 * Servlet per la gestione degli ordini del negozio online.
 * Gestisce la creazione di nuovi ordini a partire dal carrello dell'utente.
 */
@WebServlet("/shop/order")
public class OrderServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // DAO per l'accesso ai dati dei prodotti e degli ordini
    private transient ProductDao productDao;
    private transient OrderDao orderDao;

    /**
     * Inizializza i DAO necessari per le operazioni su database
     */
    @Override
    public void init() {
        productDao = new ProductDao();
        orderDao = new OrderDao();
    }

    /**
     * Gestisce le richieste POST per la creazione di un nuovo ordine.
     * Verifica l'autenticazione, la disponibilità dei prodotti e processa l'ordine.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Recupera la sessione esistente (senza crearne una nuova)
        HttpSession session = req.getSession(false);
        
        // Verifica che l'utente sia autenticato
        if (session == null || session.getAttribute("customerId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Recupera l'ID del cliente dalla sessione
        Integer customerId = (Integer) session.getAttribute("customerId");
        
        // Recupera il carrello dalla sessione
        @SuppressWarnings("unchecked")
        Map<Integer, CartItem> cart = (Map<Integer, CartItem>) session.getAttribute("cart");
        
        // Verifica che il carrello non sia vuoto
        if (cart == null || cart.isEmpty()) {
            session.setAttribute("errorMessage", "Il carrello è vuoto!");
            resp.sendRedirect(req.getContextPath() + "/shop/cart");
            return;
        }

        // Controlla la disponibilità in magazzino per tutti i prodotti nel carrello
        for (CartItem item : cart.values()) {
            int currentStock = productDao.getCurrentStock(item.getProductId());
            if (currentStock < item.getQuantity()) {
                // Se non c'è abbastanza stock, interrompe l'operazione
                session.setAttribute("errorMessage", 
                    "Stock insufficiente per " + item.getProductName() + 
                    ". Disponibili: " + currentStock);
                resp.sendRedirect(req.getContextPath() + "/shop/cart");
                return;
            }
        }

        // Calcola il totale dell'ordine sommando tutti i subtotali degli articoli
        BigDecimal total = cart.values().stream()
            .map(CartItem::getSubtotal)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        // Crea l'ordine nel database
        int orderId = orderDao.createOrder(customerId, total, cart);
        
        // Verifica se l'ordine è stato creato con successo
        if (orderId > 0) {
            // Aggiorna lo stock dei prodotti sottraendo le quantità ordinate
            for (CartItem item : cart.values()) {
                productDao.removeStock(item.getProductId(), item.getQuantity());
            }
            
            // Svuota il carrello dopo l'ordine completato
            session.removeAttribute("cart");
            
            // Imposta messaggio di successo e reindirizza alla pagina degli ordini
            session.setAttribute("successMessage", "Ordine creato con successo! ID: " + orderId);
            resp.sendRedirect(req.getContextPath() + "/shop/orders");
        } else {
            // In caso di errore nella creazione dell'ordine
            session.setAttribute("errorMessage", "Errore durante la creazione dell'ordine!");
            resp.sendRedirect(req.getContextPath() + "/shop/cart");
        }
    }
}

