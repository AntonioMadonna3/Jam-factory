package controllers;

import dao.FeedbackDao;
import model.Feedback;
import model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Servlet per la gestione delle funzionalità di degustazione e feedback sui prodotti.
 * Gestisce l'URL pattern "/taste/*" per permettere agli impiegati di visualizzare
 * e inserire feedback sui prodotti disponibili per la degustazione.
 */
@WebServlet("/taste/*")
public class TasteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // DAO per l'accesso ai dati dei feedback, dichiarato transient per evitare problemi di serializzazione
    private transient FeedbackDao feedbackDao;

    /**
     * Inizializza la servlet creando un'istanza del DAO per i feedback.
     */
    @Override
    public void init() {
        feedbackDao = new FeedbackDao();
    }

    /**
     * Gestisce le richieste GET per visualizzare la pagina principale delle degustazioni.
     * Verifica l'autenticazione dell'utente prima di permettere l'accesso.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Verifica che l'utente sia autenticato controllando la sessione
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("employeeId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Analizza il path per determinare l'azione da eseguire
        String action = req.getPathInfo();
        if (action == null || action.equals("/")) {
            // Mostra la pagina principale delle degustazioni
            showTasteHome(req, resp);
        } else {
            // Path non riconosciuto, restituisce errore 404
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    /**
     * Gestisce le richieste POST per l'inserimento di nuovi feedback.
     * Verifica l'autenticazione dell'utente prima di permettere l'accesso.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Verifica che l'utente sia autenticato controllando la sessione
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("employeeId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Analizza il path per determinare l'azione da eseguire
        String action = req.getPathInfo();
        if ("/feedback".equals(action)) {
            // Elabora l'inserimento di un nuovo feedback
            addFeedback(req, resp);
        } else {
            // Path non riconosciuto, restituisce errore 404
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    /**
     * Prepara e mostra la pagina principale delle degustazioni.
     * Carica i prodotti disponibili per feedback e i feedback già inseriti dall'impiegato.
     */
    private void showTasteHome(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Recupera l'ID dell'impiegato dalla sessione
        Integer employeeId = (Integer) req.getSession().getAttribute("employeeId");
        
        // Carica la lista dei prodotti per cui l'impiegato può ancora dare feedback
        List<Product> availableProducts = feedbackDao.getProductsAvailableForFeedback(employeeId);
        req.setAttribute("availableProducts", availableProducts);
        
        // Carica la lista dei feedback già inseriti dall'impiegato
        List<Feedback> givenFeedbacks = feedbackDao.getEmployeeFeedback(employeeId);
        req.setAttribute("givenFeedbacks", givenFeedbacks);

        // Inoltra la richiesta alla JSP per la visualizzazione
        req.getRequestDispatcher("/WEB-INF/views/taste/home.jsp")
           .forward(req, resp);
    }

    /**
     * Elabora l'inserimento di un nuovo feedback da parte dell'impiegato.
     * Valida i dati inseriti e verifica che non sia già stato dato feedback per il prodotto.
     */
    private void addFeedback(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        
        // Recupera la sessione per l'ID impiegato e per i messaggi di feedback
        HttpSession session = req.getSession();
        Integer employeeId = (Integer) session.getAttribute("employeeId");
        
        try {
            // Estrae e converte i parametri della richiesta
            int productId = Integer.parseInt(req.getParameter("productId"));
            int rating = Integer.parseInt(req.getParameter("rating"));
            String note = req.getParameter("note");
            
            // Verifica che l'impiegato non abbia già dato feedback per questo prodotto
            if (feedbackDao.hasEmployeeGivenFeedback(employeeId, productId)) {
                session.setAttribute("errorMessage", "Hai già dato un feedback per questo prodotto!");
                resp.sendRedirect(req.getContextPath() + "/taste");
                return;
            }
            
            // Valida che il rating sia nell'intervallo corretto (1-5 stelle)
            if (rating < 1 || rating > 5) {
                session.setAttribute("errorMessage", "La valutazione deve essere tra 1 e 5 stelle!");
                resp.sendRedirect(req.getContextPath() + "/taste");
                return;
            }
            
            // Tenta di inserire il feedback nel database
            boolean success = feedbackDao.addFeedback(employeeId, productId, rating, note);
            
            // Imposta il messaggio di risultato basato sull'esito dell'operazione
            if (success) {
                session.setAttribute("successMessage", "Feedback inviato con successo!");
            } else {
                session.setAttribute("errorMessage", "Errore durante l'invio del feedback!");
            }
            
        } catch (NumberFormatException e) {
            // Gestisce errori di conversione dei parametri numerici
            session.setAttribute("errorMessage", "Dati non validi!");
        }
        
        // Reindirizza alla pagina principale delle degustazioni
        resp.sendRedirect(req.getContextPath() + "/taste");
    }
}
