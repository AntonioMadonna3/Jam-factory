package controllers;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet per la gestione del logout degli utenti.
 * Invalida la sessione corrente e reindirizza alla home page.
 */
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    /**
     * Gestisce le richieste GET per il logout.
     * Verifica se esiste una sessione attiva e la invalida,
     * quindi reindirizza l'utente alla pagina principale.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // Controlla se esiste una sessione attiva senza crearne una nuova
        if (req.getSession(false) != null) {
            // Invalida la sessione corrente per effettuare il logout
            req.getSession().invalidate();
        }
        // Reindirizza l'utente alla pagina principale dell'applicazione
        resp.sendRedirect(req.getContextPath() + "/");
    }

    /**
     * Gestisce le richieste POST per il logout delegando al metodo doGet.
     * Questo permette di supportare form che inviano dati tramite POST.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        doGet(req, resp);
    }
}
