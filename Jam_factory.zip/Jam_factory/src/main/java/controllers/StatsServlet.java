package controllers;

import dao.StatsDao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Servlet che gestisce la visualizzazione delle statistiche per l'amministratore.
 * Raccoglie e prepara tutti i dati statistici del sistema per la dashboard admin.
 */
@WebServlet("/admin/stats")
public class StatsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private transient StatsDao statsDao;

    /**
     * Inizializza il DAO per l'accesso ai dati statistici
     */
    @Override
    public void init() {
        statsDao = new StatsDao();
    }

    /**
     * Gestisce le richieste GET per visualizzare le statistiche.
     * Verifica l'autorizzazione admin e raccoglie tutti i dati necessari.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Verifica che l'utente sia autenticato come amministratore
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("adminId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Raccoglie i dati di panoramica generale (totali, conteggi principali)
        Map<String, Integer> overviewStats = statsDao.getOverviewStats();
        req.setAttribute("overviewStats", overviewStats);

        // Ottiene i prodotti più venduti e meno venduti (top/bottom 10)
        List<Map<String, Object>> topSellingProducts = statsDao.getTopSellingProducts(10);
        List<Map<String, Object>> leastSellingProducts = statsDao.getLeastSellingProducts(10);
        req.setAttribute("topSellingProducts", topSellingProducts);
        req.setAttribute("leastSellingProducts", leastSellingProducts);

        // Raccoglie le statistiche sui fornitori più performanti
        List<Map<String, Object>> topSuppliers = statsDao.getTopSuppliers();
        req.setAttribute("topSuppliers", topSuppliers);

        // Ottiene i dati di vendita mensili e i migliori clienti
        List<Map<String, Object>> monthlySales = statsDao.getMonthlySales();
        List<Map<String, Object>> topCustomers = statsDao.getTopCustomers(10);
        req.setAttribute("monthlySales", monthlySales);
        req.setAttribute("topCustomers", topCustomers);
        // Calcola il valore medio degli ordini
        req.setAttribute("averageOrderValue", statsDao.getAverageOrderValue());

        // Raccoglie i dati sui feedback e valutazioni dei prodotti
        List<Map<String, Object>> topRatedProducts = statsDao.getTopRatedProducts(10);
        List<Map<String, Object>> lowestRatedProducts = statsDao.getLowestRatedProducts(10);
        List<Map<String, Object>> mostReviewedProducts = statsDao.getMostReviewedProducts(10);
        // Ottiene la distribuzione delle valutazioni (quante stelle per quanti prodotti)
        Map<Integer, Integer> ratingDistribution = statsDao.getRatingDistribution();
        
        req.setAttribute("topRatedProducts", topRatedProducts);
        req.setAttribute("lowestRatedProducts", lowestRatedProducts);
        req.setAttribute("mostReviewedProducts", mostReviewedProducts);
        req.setAttribute("ratingDistribution", ratingDistribution);

        // Inoltra alla JSP per la visualizzazione dei dati
        req.getRequestDispatcher("/WEB-INF/views/admin/stats.jsp")
           .forward(req, resp);
    }
}
