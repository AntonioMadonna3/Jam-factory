package controllers;

import dao.ProductDao;
import dao.TasteListDao;
import dao.FeedbackDao;
import model.Product;
import model.Feedback;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.HashMap;

/**
 * Servlet per la gestione del sistema TasteHunter per amministratori.
 * Gestisce la visualizzazione e modifica dei prodotti nella taste list,
 * il calcolo delle statistiche sui feedback e le operazioni CRUD sui prodotti.
 */
@WebServlet("/admin/taste/*")
public class TasteHunterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private transient ProductDao productDao;
    private transient TasteListDao tasteListDao;
    private transient FeedbackDao feedbackDao;

    /**
     * Inizializza i DAO necessari per il funzionamento del servlet.
     */
    @Override
    public void init() {
        productDao = new ProductDao();
        tasteListDao = new TasteListDao();
        feedbackDao = new FeedbackDao();
    }

    /**
     * Gestisce le richieste GET per visualizzare la pagina di gestione taste list.
     * Carica tutti i dati necessari per la dashboard amministratore.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Verifica autenticazione amministratore
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("adminId") == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Carica i prodotti attualmente presenti nella taste list
        List<Product> tasteListProducts = tasteListDao.findProductsInTasteList();
        req.setAttribute("tasteListProducts", tasteListProducts);

        // Calcola la media delle valutazioni per ogni prodotto nella taste list
        Map<Integer, Double> productRatings = new HashMap<>();
        for (Product product : tasteListProducts) {
            double avgRating = tasteListDao.getProductAverageRating(product.getId());
            productRatings.put(product.getId(), avgRating);
        }
        req.setAttribute("productRatings", productRatings);

        // Carica tutti i feedback presenti nel sistema (non solo quelli della taste list)
        List<Feedback> feedbacks = feedbackDao.getAllFeedback();
        req.setAttribute("feedbacks", feedbacks);

        // Calcola e imposta le statistiche sui feedback solo se sono presenti
        if (!feedbacks.isEmpty()) {
            // Numero totale di feedback
            req.setAttribute("totalFeedbacks", feedbacks.size());
            
            // Numero di dipendenti unici che hanno lasciato feedback
            long uniqueEmployees = feedbacks.stream()
                .map(Feedback::getEmployeeId)
                .distinct()
                .count();
            req.setAttribute("uniqueEmployees", uniqueEmployees);
            
            // Numero di prodotti unici che hanno ricevuto feedback
            long uniqueProducts = feedbacks.stream()
                .map(Feedback::getProductId)
                .distinct()
                .count();
            req.setAttribute("uniqueProducts", uniqueProducts);
            
            // Media generale di tutte le valutazioni
            double averageRating = feedbacks.stream()
                .mapToInt(Feedback::getRating)
                .average()
                .orElse(0.0);
            req.setAttribute("averageRating", averageRating);

            // Raggruppa i feedback per nome prodotto
            Map<String, List<Feedback>> feedbacksByProduct = feedbacks.stream()
                .collect(Collectors.groupingBy(Feedback::getProductName));
            req.setAttribute("feedbacksByProduct", feedbacksByProduct);

            // Calcola la media delle valutazioni per ogni prodotto
            Map<String, Double> productAverages = new HashMap<>();
            for (Map.Entry<String, List<Feedback>> entry : feedbacksByProduct.entrySet()) {
                double avg = entry.getValue().stream()
                    .mapToInt(Feedback::getRating)
                    .average()
                    .orElse(0.0);
                productAverages.put(entry.getKey(), avg);
            }
            req.setAttribute("productAverages", productAverages);
        } else {
            // Imposta valori di default quando non ci sono feedback
            req.setAttribute("totalFeedbacks", 0);
            req.setAttribute("uniqueEmployees", 0);
            req.setAttribute("uniqueProducts", 0);
            req.setAttribute("averageRating", 0.0);
            req.setAttribute("feedbacksByProduct", new HashMap<>());
            req.setAttribute("productAverages", new HashMap<>());
        }

        // Forward alla pagina JSP per la visualizzazione
        req.getRequestDispatcher("/WEB-INF/views/admin/taste.jsp")
           .forward(req, resp);
    }

    /**
     * Gestisce le richieste POST per le operazioni CRUD sui prodotti della taste list.
     * Routing delle azioni basato sul pathInfo della richiesta.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        // Estrae l'azione dal path della richiesta (/add, /remove, /update, /publish)
        String action = req.getPathInfo();
        if (action == null) { 
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST); 
            return; 
        }

        // Routing delle azioni verso i rispettivi metodi
        switch (action) {
            case "/add"     -> doAdd(req);
            case "/remove"  -> doRemove(req);
            case "/update"  -> doUpdate(req);
            case "/publish" -> doPublish(req);
            default         -> resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
        
        // Redirect alla pagina principale dopo l'operazione
        resp.sendRedirect(req.getContextPath() + "/admin/taste");
    }

    /**
     * Aggiunge un nuovo prodotto al sistema e automaticamente alla taste list.
     * Utilizzato per i prodotti in fase di test prima della pubblicazione.
     */
    private void doAdd(HttpServletRequest req) {
        String nome = req.getParameter("nome");
        String descrizione = req.getParameter("descrizione");
        BigDecimal prezzo = new BigDecimal(req.getParameter("prezzo"));
        
        // Crea e inserisce il nuovo prodotto nel database
        Product newProduct = new Product(nome, descrizione, prezzo);
        int productId = productDao.insert(newProduct);
        
        HttpSession session = req.getSession();
        if (productId > 0) {
            // Aggiunge automaticamente il prodotto alla taste list per i test
            boolean addedToTasteList = tasteListDao.addToTasteList(productId);
            if (addedToTasteList) {
                session.setAttribute("successMessage", "Prodotto '" + nome + "' creato e aggiunto alla taste list");
            } else {
                session.setAttribute("errorMessage", "Prodotto creato ma errore nell'aggiunta alla taste list");
            }
        } else {
            session.setAttribute("errorMessage", "Errore nella creazione del prodotto");
        }
    }

    /**
     * Aggiorna le informazioni di un prodotto esistente nella taste list.
     * Modifica nome, descrizione e prezzo del prodotto.
     */
    private void doUpdate(HttpServletRequest req) {
        int productId = Integer.parseInt(req.getParameter("product_id"));
        String nome = req.getParameter("nome");
        String descrizione = req.getParameter("descrizione");
        BigDecimal prezzo = new BigDecimal(req.getParameter("prezzo"));
        
        // Crea l'oggetto prodotto aggiornato e lo salva
        Product product = new Product(productId, nome, descrizione, prezzo, 0);
        boolean success = productDao.update(product);
        
        HttpSession session = req.getSession();
        if (success) {
            session.setAttribute("successMessage", "Prodotto '" + nome + "' aggiornato con successo");
        } else {
            session.setAttribute("errorMessage", "Errore nell'aggiornamento del prodotto");
        }
    }

    /**
     * Rimuove un prodotto dalla taste list.
     * Il prodotto rimane nel sistema ma non è più disponibile per i test.
     */
    private void doRemove(HttpServletRequest req) {
        int productId = Integer.parseInt(req.getParameter("product_id"));
        
        // Rimuove il prodotto dalla taste list
        boolean removedFromTasteList = tasteListDao.removeFromTasteList(productId);
        
        HttpSession session = req.getSession();
        if (removedFromTasteList) {
            session.setAttribute("successMessage", "Prodotto rimosso dalla taste list");
        } else {
            session.setAttribute("errorMessage", "Errore nella rimozione del prodotto");
        }
    }

    /**
     * Pubblica un prodotto dalla taste list rendendolo disponibile nello shop.
     * Rimuove il prodotto dalla taste list e lo rende disponibile per l'acquisto.
     */
    private void doPublish(HttpServletRequest req) {
        int productId = Integer.parseInt(req.getParameter("product_id"));
        
        HttpSession session = req.getSession();
        
        // Rimuove dalla taste list per renderlo disponibile in prodotti e shop
        boolean removed = tasteListDao.removeFromTasteList(productId);
        
        if (removed) {
            // Assicura che esista una riga nello stock (con quantità iniziale 0)
            productDao.ensureStockExists(productId);
            session.setAttribute("successMessage", "Prodotto pubblicato! Ora è disponibile nella gestione prodotti e nello shop.");
        } else {
            session.setAttribute("errorMessage", "Errore nella pubblicazione del prodotto");
        }
    }
}
